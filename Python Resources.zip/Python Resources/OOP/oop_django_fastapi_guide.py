"""
OOP IN DJANGO & FASTAPI - FRAMEWORK-SPECIFIC GUIDE
==================================================

This guide shows exactly how OOP concepts are used in Django and FastAPI.
Study these patterns to understand real framework code.
"""

# ==============================================================================
# PART 1: DJANGO OOP PATTERNS
# ==============================================================================

"""
DJANGO ARCHITECTURE OVERVIEW:
- Models: Classes that represent database tables (ORM)
- Views: Classes that handle HTTP requests
- Forms: Classes that validate and process form data
- Serializers (DRF): Classes that convert models to JSON
- Managers: Classes that handle database queries
- Middleware: Classes that process requests/responses
"""

# ------------------------------------------------------------------------------
# 1. DJANGO MODELS - OOP IN ACTION
# ------------------------------------------------------------------------------

"""
Real Django Model Example:

from django.db import models
from django.contrib.auth.models import User

class BlogPost(models.Model):
    '''
    This is a real Django model showing OOP concepts:
    - Inheritance: Inherits from models.Model
    - Class attributes: Define database fields
    - Instance methods: Business logic
    - Class Meta: Configuration
    - Properties: Computed fields
    - Magic methods: __str__, __repr__
    '''
    
    # Class attributes (become database columns)
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)  # Relationship
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published = models.BooleanField(default=False)
    views = models.IntegerField(default=0)
    
    # Tags - Many-to-Many relationship
    tags = models.ManyToManyField('Tag', related_name='posts')
    
    class Meta:
        '''Inner class for model configuration'''
        ordering = ['-created_at']
        verbose_name = 'Blog Post'
        verbose_name_plural = 'Blog Posts'
        indexes = [
            models.Index(fields=['slug']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        '''String representation (used in admin)'''
        return self.title
    
    def __repr__(self):
        '''Developer representation'''
        return f"<BlogPost: {self.title}>"
    
    def save(self, *args, **kwargs):
        '''Override save method (method overriding)'''
        # Custom logic before saving
        if not self.slug:
            self.slug = self.generate_slug()
        super().save(*args, **kwargs)  # Call parent save
    
    def delete(self, *args, **kwargs):
        '''Override delete method'''
        # Custom cleanup logic
        self.clear_cache()
        super().delete(*args, **kwargs)
    
    # Instance methods (business logic)
    def publish(self):
        '''Publish the post'''
        self.published = True
        self.save()
    
    def unpublish(self):
        '''Unpublish the post'''
        self.published = False
        self.save()
    
    def increment_views(self):
        '''Track views'''
        self.views += 1
        self.save(update_fields=['views'])  # Only update one field
    
    # Property decorator (computed field)
    @property
    def excerpt(self):
        '''First 200 characters of content'''
        return self.content[:200] + '...' if len(self.content) > 200 else self.content
    
    @property
    def read_time(self):
        '''Estimated reading time in minutes'''
        words = len(self.content.split())
        return max(1, words // 200)  # Assume 200 words per minute
    
    @property
    def is_recent(self):
        '''Check if post is less than 7 days old'''
        from django.utils import timezone
        from datetime import timedelta
        return timezone.now() - self.created_at < timedelta(days=7)
    
    # Class method
    @classmethod
    def published_posts(cls):
        '''Get all published posts - alternative to Manager'''
        return cls.objects.filter(published=True)
    
    # Static method
    @staticmethod
    def generate_slug_from_title(title):
        '''Generate URL-friendly slug'''
        import re
        slug = title.lower()
        slug = re.sub(r'[^a-z0-9]+', '-', slug)
        return slug.strip('-')
    
    def get_absolute_url(self):
        '''Standard Django method for getting object URL'''
        from django.urls import reverse
        return reverse('blog:post_detail', kwargs={'slug': self.slug})
    
    def get_related_posts(self, count=5):
        '''Get related posts by tags'''
        return BlogPost.objects.filter(
            tags__in=self.tags.all()
        ).exclude(id=self.id).distinct()[:count]

"""

# Simplified version you can run:
class BlogPostSimulation:
    """Simulates Django model behavior"""
    
    # Simulate Django's objects manager
    _all_posts = []
    
    def __init__(self, title, content, author):
        self.title = title
        self.content = content
        self.author = author
        self.published = False
        self.views = 0
        self.slug = self.generate_slug_from_title(title)
        BlogPostSimulation._all_posts.append(self)
    
    @classmethod
    def objects_all(cls):
        """Simulate Django's objects.all()"""
        return cls._all_posts
    
    @classmethod
    def objects_filter(cls, **kwargs):
        """Simulate Django's objects.filter()"""
        results = cls._all_posts
        for key, value in kwargs.items():
            results = [post for post in results if getattr(post, key) == value]
        return results
    
    def save(self):
        """Simulate saving to database"""
        print(f"Saving {self.title} to database...")
    
    def publish(self):
        """Business logic method"""
        self.published = True
        self.save()
    
    @property
    def excerpt(self):
        """Computed property"""
        return self.content[:100] + "..." if len(self.content) > 100 else self.content
    
    @staticmethod
    def generate_slug_from_title(title):
        """Static utility method"""
        import re
        slug = title.lower()
        slug = re.sub(r'[^a-z0-9]+', '-', slug)
        return slug.strip('-')
    
    def __str__(self):
        return f"BlogPost: {self.title}"

# Test it
post1 = BlogPostSimulation("Learning OOP", "This is content about OOP...", "Paul")
post2 = BlogPostSimulation("Django Guide", "Django is a web framework...", "Paul")
post1.publish()

print(f"All posts: {len(BlogPostSimulation.objects_all())}")
print(f"Published posts: {len(BlogPostSimulation.objects_filter(published=True))}")


# ------------------------------------------------------------------------------
# 2. DJANGO MANAGERS - CUSTOM QUERY LOGIC
# ------------------------------------------------------------------------------

"""
Real Django Manager:

class PublishedManager(models.Manager):
    '''Custom manager for published posts'''
    
    def get_queryset(self):
        '''Override to filter published only'''
        return super().get_queryset().filter(published=True)
    
    def recent(self, days=7):
        '''Get recent posts'''
        from django.utils import timezone
        from datetime import timedelta
        cutoff = timezone.now() - timedelta(days=days)
        return self.get_queryset().filter(created_at__gte=cutoff)

class BlogPost(models.Model):
    # ... fields ...
    
    # Default manager
    objects = models.Manager()
    
    # Custom manager
    published = PublishedManager()
    
    # Usage:
    # all_posts = BlogPost.objects.all()  # All posts
    # published_posts = BlogPost.published.all()  # Only published
    # recent = BlogPost.published.recent(days=3)  # Recent published
"""


# ------------------------------------------------------------------------------
# 3. DJANGO CLASS-BASED VIEWS (CBV) - INHERITANCE & MIXINS
# ------------------------------------------------------------------------------

"""
Real Django Views showing OOP:

from django.views.generic import ListView, DetailView, CreateView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404

# Multiple inheritance with mixins
class BlogPostListView(LoginRequiredMixin, ListView):
    '''
    Shows OOP concepts:
    - Multiple inheritance (LoginRequiredMixin + ListView)
    - Mixins (LoginRequiredMixin adds authentication)
    - Method overriding (get_queryset, get_context_data)
    - Class attributes for configuration
    '''
    model = BlogPost
    template_name = 'blog/post_list.html'
    context_object_name = 'posts'
    paginate_by = 10
    
    def get_queryset(self):
        '''Override to customize query'''
        return BlogPost.published.all().select_related('author')
    
    def get_context_data(self, **kwargs):
        '''Override to add extra context'''
        context = super().get_context_data(**kwargs)
        context['total_posts'] = BlogPost.objects.count()
        return context


class BlogPostDetailView(DetailView):
    '''Detail view for single post'''
    model = BlogPost
    template_name = 'blog/post_detail.html'
    context_object_name = 'post'
    
    def get_object(self):
        '''Override to customize object retrieval'''
        post = super().get_object()
        post.increment_views()  # Track views
        return post


class BlogPostCreateView(LoginRequiredMixin, CreateView):
    '''Create new post - shows form handling'''
    model = BlogPost
    fields = ['title', 'content', 'tags']
    template_name = 'blog/post_form.html'
    
    def form_valid(self, form):
        '''Override to set author before saving'''
        form.instance.author = self.request.user
        return super().form_valid(form)


# Custom mixin (composition of behavior)
class OwnerRequiredMixin:
    '''Only allow owner to access'''
    
    def dispatch(self, request, *args, **kwargs):
        obj = self.get_object()
        if obj.author != request.user:
            raise PermissionDenied
        return super().dispatch(request, *args, **kwargs)


class BlogPostUpdateView(LoginRequiredMixin, OwnerRequiredMixin, UpdateView):
    '''Update post - combines multiple mixins'''
    model = BlogPost
    fields = ['title', 'content', 'tags']
    template_name = 'blog/post_form.html'
"""


# ------------------------------------------------------------------------------
# 4. DJANGO REST FRAMEWORK SERIALIZERS
# ------------------------------------------------------------------------------

"""
Real DRF Serializer:

from rest_framework import serializers

class UserSerializer(serializers.ModelSerializer):
    '''
    Serializers show OOP concepts:
    - Inheritance from ModelSerializer
    - Nested serializers (composition)
    - Validation methods
    - Computed fields
    '''
    
    # Computed field (not in model)
    full_name = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'full_name']
        read_only_fields = ['id']
    
    def get_full_name(self, obj):
        '''Method for computed field'''
        return f"{obj.first_name} {obj.last_name}"
    
    def validate_username(self, value):
        '''Field-level validation'''
        if len(value) < 3:
            raise serializers.ValidationError("Username too short")
        return value
    
    def validate(self, data):
        '''Object-level validation'''
        # Validate multiple fields together
        return data


class BlogPostSerializer(serializers.ModelSerializer):
    '''Serializer with nested relationships'''
    
    # Nested serializer
    author = UserSerializer(read_only=True)
    
    # Many-to-many relationship
    tags = serializers.StringRelatedField(many=True)
    
    # Computed fields
    excerpt = serializers.ReadOnlyField()
    read_time = serializers.ReadOnlyField()
    
    class Meta:
        model = BlogPost
        fields = ['id', 'title', 'slug', 'content', 'author', 
                  'tags', 'excerpt', 'read_time', 'created_at']
        read_only_fields = ['id', 'slug', 'created_at']
    
    def create(self, validated_data):
        '''Override create method'''
        # Custom creation logic
        return BlogPost.objects.create(**validated_data)
    
    def update(self, instance, validated_data):
        '''Override update method'''
        # Custom update logic
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance
"""


# ==============================================================================
# PART 2: FASTAPI OOP PATTERNS
# ==============================================================================

"""
FASTAPI ARCHITECTURE:
- Pydantic Models: Data validation and serialization
- Path Operations: Functions decorated with @app.get, @app.post
- Dependencies: Reusable components (Dependency Injection)
- Background Tasks: Async operations
- Middleware: Request/response processing
"""


# ------------------------------------------------------------------------------
# 1. PYDANTIC MODELS - TYPE VALIDATION
# ------------------------------------------------------------------------------

"""
Real Pydantic Model (FastAPI):

from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from datetime import datetime

class UserBase(BaseModel):
    '''
    Pydantic models show OOP:
    - Inheritance from BaseModel
    - Type hints for validation
    - Validators for custom logic
    - Config class for settings
    '''
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: Optional[str] = None
    
    @validator('username')
    def username_alphanumeric(cls, v):
        '''Custom validator'''
        if not v.isalnum():
            raise ValueError('Username must be alphanumeric')
        return v
    
    class Config:
        '''Configuration'''
        orm_mode = True  # Allow creating from ORM models


class UserCreate(UserBase):
    '''Model for user creation'''
    password: str = Field(..., min_length=8)
    
    @validator('password')
    def password_strength(cls, v):
        '''Validate password strength'''
        if not any(char.isdigit() for char in v):
            raise ValueError('Password must contain digit')
        if not any(char.isupper() for char in v):
            raise ValueError('Password must contain uppercase')
        return v


class UserResponse(UserBase):
    '''Model for API response'''
    id: int
    created_at: datetime
    is_active: bool = True
    
    class Config:
        orm_mode = True


class BlogPostBase(BaseModel):
    '''Base model for blog post'''
    title: str = Field(..., min_length=5, max_length=200)
    content: str = Field(..., min_length=10)
    tags: List[str] = []


class BlogPostCreate(BlogPostBase):
    '''Model for creating posts'''
    pass


class BlogPostResponse(BlogPostBase):
    '''Model for API response with computed fields'''
    id: int
    slug: str
    author: UserResponse  # Nested model
    created_at: datetime
    published: bool
    views: int
    
    class Config:
        orm_mode = True


# Usage in FastAPI:
from fastapi import FastAPI, HTTPException, Depends

app = FastAPI()

@app.post("/users/", response_model=UserResponse)
async def create_user(user: UserCreate):
    '''
    FastAPI automatically:
    - Validates input against UserCreate model
    - Returns data matching UserResponse model
    - Generates OpenAPI documentation
    '''
    # Create user logic
    return {"id": 1, "username": user.username, "email": user.email, 
            "created_at": datetime.now()}
"""

# Simplified version you can run:
from typing import Optional, List
from datetime import datetime

class PydanticModelSimulation:
    """Simulates Pydantic BaseModel behavior"""
    
    def __init__(self, **kwargs):
        """Initialize with validation"""
        for key, value in kwargs.items():
            setattr(self, key, value)
        self.validate()
    
    def validate(self):
        """Override in subclasses"""
        pass
    
    def dict(self):
        """Return as dictionary"""
        return {k: v for k, v in self.__dict__.items() 
                if not k.startswith('_')}

class UserCreate(PydanticModelSimulation):
    """User creation model"""
    
    def validate(self):
        """Validation logic"""
        if not hasattr(self, 'username') or len(self.username) < 3:
            raise ValueError("Username must be at least 3 characters")
        if not hasattr(self, 'email') or '@' not in self.email:
            raise ValueError("Invalid email")
        if not hasattr(self, 'password') or len(self.password) < 8:
            raise ValueError("Password must be at least 8 characters")
        
        # Validate password strength
        if not any(c.isdigit() for c in self.password):
            raise ValueError("Password must contain a digit")
        if not any(c.isupper() for c in self.password):
            raise ValueError("Password must contain uppercase letter")

# Test
user = UserCreate(
    username="paulifemene",
    email="paul@example.com",
    password="SecurePass123"
)
print(f"Valid user: {user.dict()}")


# ------------------------------------------------------------------------------
# 2. FASTAPI DEPENDENCIES - DEPENDENCY INJECTION
# ------------------------------------------------------------------------------

"""
Real FastAPI Dependencies:

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer

# OAuth2 scheme (class instance)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class DatabaseSession:
    '''Dependency for database session'''
    
    def __init__(self):
        self.db = get_database_connection()
    
    def __enter__(self):
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.db.close()


def get_db():
    '''Dependency function'''
    db = DatabaseSession()
    try:
        yield db
    finally:
        db.close()


def get_current_user(token: str = Depends(oauth2_scheme), 
                     db = Depends(get_db)):
    '''Dependency that requires other dependencies'''
    user = authenticate_token(token, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    return user


class PermissionChecker:
    '''Callable class as dependency'''
    
    def __init__(self, required_permission: str):
        self.required_permission = required_permission
    
    def __call__(self, user = Depends(get_current_user)):
        '''Make class instance callable'''
        if self.required_permission not in user.permissions:
            raise HTTPException(status_code=403, detail="No permission")
        return user


# Usage in routes:
@app.get("/posts/")
async def get_posts(db = Depends(get_db)):
    '''Route with database dependency'''
    return db.query(BlogPost).all()


@app.get("/posts/me")
async def get_my_posts(current_user = Depends(get_current_user),
                       db = Depends(get_db)):
    '''Route with authentication'''
    return db.query(BlogPost).filter(author=current_user).all()


@app.delete("/posts/{post_id}")
async def delete_post(post_id: int,
                      user = Depends(PermissionChecker("delete_post")),
                      db = Depends(get_db)):
    '''Route with permission check'''
    post = db.query(BlogPost).get(post_id)
    db.delete(post)
    return {"status": "deleted"}
"""


# ------------------------------------------------------------------------------
# 3. FASTAPI ROUTERS - ORGANIZATION
# ------------------------------------------------------------------------------

"""
Real FastAPI Router:

from fastapi import APIRouter, Depends

router = APIRouter(
    prefix="/api/posts",
    tags=["posts"],
    dependencies=[Depends(get_current_user)]  # Apply to all routes
)

@router.get("/")
async def list_posts():
    '''List all posts'''
    return {"posts": []}

@router.post("/")
async def create_post(post: BlogPostCreate):
    '''Create new post'''
    return {"id": 1, **post.dict()}

@router.get("/{post_id}")
async def get_post(post_id: int):
    '''Get single post'''
    return {"id": post_id}

# Include router in main app
from fastapi import FastAPI

app = FastAPI()
app.include_router(router)
"""


# ==============================================================================
# PART 3: COMPARING DJANGO VS FASTAPI OOP
# ==============================================================================

print("""
DJANGO VS FASTAPI - OOP COMPARISON
==================================

DJANGO (Synchronous, ORM-focused):
----------------------------------
1. Models inherit from models.Model
2. Heavy use of inheritance (CBV, forms, admin)
3. Manager classes for queries
4. Mixins for reusable behavior
5. Metaclasses for model fields
6. Serializers for REST APIs (DRF)

Example inheritance chain:
BlogPost -> models.Model -> <metaclass magic>

FASTAPI (Asynchronous, Pydantic-focused):
-----------------------------------------
1. Models inherit from pydantic.BaseModel
2. Dependency injection over inheritance
3. Type hints for validation
4. Functional programming style (decorators)
5. Less magic, more explicit
6. Built-in async support

Example:
class User(BaseModel):  # Clean inheritance
    username: str       # Type validation
    email: EmailStr     # Custom types


KEY DIFFERENCES:
---------------
1. Django uses inheritance heavily, FastAPI prefers composition
2. Django has implicit magic, FastAPI is explicit
3. Django ORM handles database, FastAPI is database-agnostic
4. Django uses class-based views, FastAPI uses function decorators
5. Django serializers are classes, FastAPI uses Pydantic models


WHEN TO USE WHICH:
-----------------
DJANGO:
- Full-stack web applications
- Admin panel needed
- Complex database relationships
- Traditional request-response cycle
- Team familiar with Django patterns

FASTAPI:
- Modern APIs
- Microservices
- High performance needed
- Async operations
- OpenAPI documentation important
- Type safety critical


COMMONALITIES:
-------------
Both use OOP principles:
- Encapsulation: Private attributes, methods
- Inheritance: Base classes, mixins
- Polymorphism: Interface implementations
- Abstraction: Abstract base classes
- Composition: Nested objects, relationships
""")


# ==============================================================================
# PART 4: PRACTICAL PATTERNS FOR BOTH
# ==============================================================================

class BaseRepository:
    """Repository pattern - works with both Django and FastAPI"""
    
    def get_all(self):
        raise NotImplementedError
    
    def get_by_id(self, id):
        raise NotImplementedError
    
    def create(self, data):
        raise NotImplementedError
    
    def update(self, id, data):
        raise NotImplementedError
    
    def delete(self, id):
        raise NotImplementedError


class DjangoPostRepository(BaseRepository):
    """Django implementation"""
    
    def get_all(self):
        """return BlogPost.objects.all()"""
        pass
    
    def get_by_id(self, id):
        """return BlogPost.objects.get(id=id)"""
        pass


class FastAPIPostRepository(BaseRepository):
    """FastAPI implementation"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    def get_all(self):
        """return self.db.query(BlogPost).all()"""
        pass


print("\n" + "="*70)
print("NEXT STEPS FOR MASTERY")
print("="*70)
print("""
1. Build a Django Blog:
   - Models with relationships
   - Class-based views
   - Admin customization
   - REST API with DRF

2. Build a FastAPI Service:
   - Pydantic models
   - Path operations
   - Dependencies
   - Database integration

3. Study Real Code:
   - Django source code (github.com/django/django)
   - FastAPI source code (github.com/tiangolo/fastapi)
   - Django REST Framework
   - Real-world projects

4. Practice Design Patterns:
   - Repository pattern
   - Factory pattern
   - Strategy pattern
   - Observer pattern

5. Read Documentation:
   - Django docs (docs.djangoproject.com)
   - FastAPI docs (fastapi.tiangolo.com)
   - Pydantic docs
   - Python docs on OOP

You now have the foundation to understand and build with both frameworks! 🚀
""")
