"""
OOP PYTHON QUICK REFERENCE CHEAT SHEET
======================================

Quick lookup for all OOP concepts. Use this for rapid review!
"""

# ==============================================================================
# 1. CLASS BASICS
# ==============================================================================

# Simple class
class Dog:
    pass

# Class with constructor
class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age

# Class with methods
class Dog:
    def __init__(self, name):
        self.name = name
    
    def bark(self):
        return f"{self.name} says Woof!"

# ==============================================================================
# 2. ATTRIBUTES
# ==============================================================================

class Product:
    # Class attribute (shared)
    store_name = "MyStore"
    
    def __init__(self, name, price):
        # Instance attributes (unique)
        self.name = name
        self.price = price

# ==============================================================================
# 3. ENCAPSULATION
# ==============================================================================

class BankAccount:
    def __init__(self, balance):
        self.public = "accessible"           # Public
        self._protected = "convention only"  # Protected
        self.__private = balance             # Private (name mangling)
    
    def get_balance(self):
        return self.__private  # Getter

# ==============================================================================
# 4. INHERITANCE
# ==============================================================================

# Single inheritance
class Animal:
    def speak(self):
        return "sound"

class Dog(Animal):
    def speak(self):  # Override
        return "Woof"

# Multiple inheritance
class Flyer:
    def fly(self):
        return "flying"

class Swimmer:
    def swim(self):
        return "swimming"

class Duck(Flyer, Swimmer):
    pass

# super() - call parent method
class Dog(Animal):
    def __init__(self, name):
        super().__init__()  # Call parent __init__
        self.name = name

# ==============================================================================
# 5. POLYMORPHISM
# ==============================================================================

# Method overriding
class Cat(Animal):
    def speak(self):  # Different implementation
        return "Meow"

# Duck typing
def make_sound(animal):
    return animal.speak()  # Works with any object that has speak()

# ==============================================================================
# 6. ABSTRACTION
# ==============================================================================

from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass  # Must be implemented by subclasses

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius
    
    def area(self):
        return 3.14 * self.radius ** 2

# ==============================================================================
# 7. MAGIC METHODS
# ==============================================================================

class Book:
    def __init__(self, title):
        self.title = title
    
    def __str__(self):           # print(book)
        return self.title
    
    def __repr__(self):          # repr(book)
        return f"Book('{self.title}')"
    
    def __len__(self):           # len(book)
        return self.pages
    
    def __eq__(self, other):     # book1 == book2
        return self.title == other.title
    
    def __lt__(self, other):     # book1 < book2
        return self.pages < other.pages
    
    def __add__(self, other):    # book1 + book2
        return self.price + other.price
    
    def __getitem__(self, key):  # book[0]
        return self.chapters[key]
    
    def __setitem__(self, key, value):  # book[0] = chapter
        self.chapters[key] = value
    
    def __contains__(self, item):  # "word" in book
        return item in self.content
    
    def __iter__(self):          # for x in book
        return iter(self.chapters)
    
    def __call__(self):          # book()
        return "Called!"
    
    def __enter__(self):         # with book as f:
        return self
    
    def __exit__(self, *args):
        self.close()

# ==============================================================================
# 8. CLASS METHODS & STATIC METHODS
# ==============================================================================

class Employee:
    company = "TechCorp"
    
    def __init__(self, name):
        self.name = name
    
    # Instance method (needs self)
    def work(self):
        return f"{self.name} is working"
    
    # Class method (needs cls)
    @classmethod
    def from_string(cls, emp_str):
        name, salary = emp_str.split('-')
        return cls(name)
    
    @classmethod
    def set_company(cls, name):
        cls.company = name
    
    # Static method (needs neither)
    @staticmethod
    def is_workday(day):
        return day not in ['Saturday', 'Sunday']

# Usage:
emp = Employee.from_string("John-50000")  # Alternative constructor
Employee.set_company("NewCorp")           # Modify class attribute
Employee.is_workday("Monday")             # Utility function

# ==============================================================================
# 9. PROPERTIES
# ==============================================================================

class Temperature:
    def __init__(self, celsius):
        self._celsius = celsius
    
    @property
    def celsius(self):           # Getter
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):    # Setter
        if value < -273.15:
            raise ValueError("Too cold!")
        self._celsius = value
    
    @celsius.deleter
    def celsius(self):           # Deleter
        del self._celsius
    
    @property
    def fahrenheit(self):        # Read-only computed property
        return self._celsius * 9/5 + 32

# Usage:
temp = Temperature(25)
print(temp.celsius)      # Calls getter
temp.celsius = 30        # Calls setter
print(temp.fahrenheit)   # Computed property
del temp.celsius         # Calls deleter

# ==============================================================================
# 10. COMPOSITION
# ==============================================================================

class Engine:
    def start(self):
        return "Engine started"

class Car:
    def __init__(self):
        self.engine = Engine()  # HAS-A relationship
    
    def start(self):
        return self.engine.start()

# ==============================================================================
# 11. COMMON DESIGN PATTERNS
# ==============================================================================

# Singleton
class Database:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

# Factory
class AnimalFactory:
    @staticmethod
    def create(animal_type):
        if animal_type == "dog":
            return Dog()
        elif animal_type == "cat":
            return Cat()

# Observer
class Subject:
    def __init__(self):
        self._observers = []
    
    def attach(self, observer):
        self._observers.append(observer)
    
    def notify(self):
        for observer in self._observers:
            observer.update()

# ==============================================================================
# 12. DJANGO PATTERNS
# ==============================================================================

"""
# Django Model
class BlogPost(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        # Custom logic
        super().save(*args, **kwargs)

# Django View
class PostListView(ListView):
    model = BlogPost
    template_name = 'posts.html'
    
    def get_queryset(self):
        return BlogPost.objects.filter(published=True)

# Django Serializer (DRF)
class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = BlogPost
        fields = ['id', 'title', 'content']
"""

# ==============================================================================
# 13. FASTAPI PATTERNS
# ==============================================================================

"""
# Pydantic Model
class User(BaseModel):
    username: str
    email: EmailStr
    age: int = Field(..., ge=0, le=120)
    
    @validator('username')
    def username_alphanumeric(cls, v):
        assert v.isalnum(), 'must be alphanumeric'
        return v

# FastAPI Route
@app.post("/users/", response_model=UserResponse)
async def create_user(user: UserCreate):
    return create_user_in_db(user)

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/users/")
async def get_users(db = Depends(get_db)):
    return db.query(User).all()
"""

# ==============================================================================
# 14. BEST PRACTICES CHECKLIST
# ==============================================================================

"""
✓ Use meaningful class names (PascalCase)
✓ One class per responsibility (Single Responsibility Principle)
✓ Prefer composition over inheritance when possible
✓ Use properties for computed attributes
✓ Implement __str__ and __repr__ for debugging
✓ Use abstract base classes for interfaces
✓ Document classes with docstrings
✓ Use type hints (Python 3.6+)
✓ Follow SOLID principles
✓ Keep methods small and focused
✓ Use private attributes (_name) for internal use
✓ Validate in setters/properties
✓ Use class methods for alternative constructors
✓ Use static methods for utility functions
✓ Handle exceptions properly
"""

# ==============================================================================
# 15. COMMON MISTAKES TO AVOID
# ==============================================================================

"""
❌ Modifying class attributes thinking they're instance attributes
   class Dog:
       tricks = []  # WRONG - shared by all instances!
   
   ✓ class Dog:
       def __init__(self):
           self.tricks = []  # CORRECT - unique per instance

❌ Forgetting self parameter
   def bark():  # WRONG
       return "Woof"
   
   ✓ def bark(self):  # CORRECT
       return "Woof"

❌ Not calling super().__init__()
   class Dog(Animal):
       def __init__(self, name):
           self.name = name  # WRONG - parent not initialized
   
   ✓ class Dog(Animal):
       def __init__(self, name):
           super().__init__()  # CORRECT
           self.name = name

❌ Using inheritance when composition is better
   class Manager(Employee, Database, Logger):  # WRONG - too coupled
   
   ✓ class Manager(Employee):  # CORRECT
       def __init__(self):
           self.db = Database()
           self.logger = Logger()

❌ Making everything public
   class User:
       def __init__(self, password):
           self.password = password  # WRONG - should be private
   
   ✓ class User:
       def __init__(self, password):
           self.__password = password  # CORRECT
"""

# ==============================================================================
# 16. SOLID PRINCIPLES
# ==============================================================================

"""
S - Single Responsibility Principle
    Each class should have one job

O - Open/Closed Principle
    Open for extension, closed for modification

L - Liskov Substitution Principle
    Subclasses should be substitutable for base classes

I - Interface Segregation Principle
    Many specific interfaces > one general interface

D - Dependency Inversion Principle
    Depend on abstractions, not concrete classes
"""

# ==============================================================================
# 17. QUICK SYNTAX REFERENCE
# ==============================================================================

"""
# Create class:              class ClassName:
# Create object:             obj = ClassName()
# Instance attribute:        self.attribute = value
# Class attribute:           ClassName.attribute = value
# Instance method:           def method(self):
# Class method:              @classmethod def method(cls):
# Static method:             @staticmethod def method():
# Property:                  @property def attribute(self):
# Inheritance:               class Child(Parent):
# Multiple inheritance:      class Child(Parent1, Parent2):
# Call parent method:        super().method()
# Private attribute:         self.__private
# Protected attribute:       self._protected
# Abstract class:            from abc import ABC, abstractmethod
# Magic method:              def __method__(self):
"""

# ==============================================================================
# 18. TESTING OOP CODE
# ==============================================================================

"""
import unittest

class TestDog(unittest.TestCase):
    def setUp(self):
        self.dog = Dog("Buddy", 3)
    
    def test_initialization(self):
        self.assertEqual(self.dog.name, "Buddy")
        self.assertEqual(self.dog.age, 3)
    
    def test_bark(self):
        self.assertEqual(self.dog.bark(), "Buddy says Woof!")
    
    def tearDown(self):
        del self.dog
"""

print("""
================================================================================
STUDY PLAN FOR MASTERY
================================================================================

WEEK 1-2: Fundamentals
- Classes, objects, attributes, methods
- Encapsulation
- Complete exercises 1-3

WEEK 3-4: Intermediate
- Inheritance (all types)
- Polymorphism
- Magic methods
- Complete exercises 4-6

WEEK 5-6: Advanced
- Abstraction
- Properties
- Class/static methods
- Design patterns
- Complete exercises 7-9

WEEK 7-8: Frameworks
- Study Django patterns
- Study FastAPI patterns
- Build real projects
- Complete exercise 10 (capstone)

WEEK 9-10: Mastery
- Build Django blog
- Build FastAPI service
- Contribute to open source
- Review and refactor your code

DAILY PRACTICE:
- Code for 1 hour minimum
- Read documentation
- Study real-world code
- Build something small
- Review concepts

RESOURCES:
- Official Python docs
- Django documentation
- FastAPI documentation
- Real Python tutorials
- GitHub projects
- Stack Overflow

Remember: Understanding > Memorization!
Practice builds intuition. Build real projects!
================================================================================
""")
