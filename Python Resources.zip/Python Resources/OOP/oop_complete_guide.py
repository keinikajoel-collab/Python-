"""
COMPLETE OOP IN PYTHON - FROM FUNDAMENTALS TO FRAMEWORKS
========================================================

This guide covers all OOP concepts with real-world examples that prepare you
for frameworks like Django and FastAPI.

Table of Contents:
1. Classes and Objects - The Foundation
2. Attributes and Methods
3. The __init__ Constructor
4. Encapsulation (Private, Protected, Public)
5. Inheritance (Single, Multiple, Multilevel)
6. Polymorphism (Method Overriding, Duck Typing)
7. Abstraction (Abstract Classes and Interfaces)
8. Special Methods (Magic/Dunder Methods)
9. Class Methods and Static Methods
10. Property Decorators
11. Composition vs Inheritance
12. Design Patterns (Common in Django/FastAPI)
"""

# ==============================================================================
# 1. CLASSES AND OBJECTS - THE FOUNDATION
# ==============================================================================
"""
CONCEPT: A class is a blueprint for creating objects. An object is an instance
of a class with actual data.

REAL-WORLD: Think of a class as an architectural blueprint, and objects as
actual buildings constructed from that blueprint.

DJANGO/FASTAPI USAGE: Models in Django and Pydantic models in FastAPI are classes.
"""

class User:
    """Basic user class - similar to Django User model"""
    pass

# Creating objects (instances)
user1 = User()
user2 = User()
print(f"user1 is a {type(user1)}")  # <class '__main__.User'>
print(f"Are they the same object? {user1 is user2}")  # False


# ==============================================================================
# 2. ATTRIBUTES AND METHODS
# ==============================================================================
"""
ATTRIBUTES: Variables that belong to a class/object (data)
METHODS: Functions that belong to a class (behavior)

Types of Attributes:
- Instance attributes: Unique to each object
- Class attributes: Shared by all objects
"""

class Product:
    """E-commerce product - like Django models"""
    
    # Class attribute (shared by all instances)
    store_name = "TechShop"
    total_products = 0
    
    def __init__(self, name, price, stock):
        # Instance attributes (unique to each instance)
        self.name = name
        self.price = price
        self.stock = stock
        Product.total_products += 1
    
    # Instance method (operates on instance data)
    def display_info(self):
        return f"{self.name}: ${self.price} ({self.stock} in stock)"
    
    # Instance method that modifies state
    def apply_discount(self, percentage):
        """Apply discount - similar to Django model methods"""
        self.price = self.price * (1 - percentage / 100)
        return self.price

# Usage
laptop = Product("Laptop", 1200, 15)
phone = Product("Phone", 800, 30)

print(laptop.display_info())
print(f"Total products: {Product.total_products}")
laptop.apply_discount(10)
print(f"After discount: ${laptop.price}")


# ==============================================================================
# 3. THE __init__ CONSTRUCTOR
# ==============================================================================
"""
CONCEPT: __init__ is automatically called when creating an object.
It initializes the object's state.

REAL-WORLD: Like a factory setup where you configure a product before shipping.

CRITICAL FOR FRAMEWORKS: Django models and FastAPI Pydantic models use this.
"""

class DatabaseConnection:
    """Similar to Django database connection"""
    
    def __init__(self, host, port, database, username, password=None):
        self.host = host
        self.port = port
        self.database = database
        self.username = username
        self._password = password  # Protected attribute
        self.connected = False
        print(f"Database connection object created for {database}")
    
    def connect(self):
        """Simulate connection"""
        self.connected = True
        return f"Connected to {self.database} at {self.host}:{self.port}"

# Creating with different configurations
db = DatabaseConnection("localhost", 5432, "shop_db", "admin", "secret123")
print(db.connect())


# ==============================================================================
# 4. ENCAPSULATION - DATA HIDING AND ACCESS CONTROL
# ==============================================================================
"""
CONCEPT: Restricting direct access to some object components.

PYTHON CONVENTIONS:
- public: normal_attribute (accessible everywhere)
- protected: _protected_attribute (should not be accessed outside class)
- private: __private_attribute (name mangling, harder to access)

REAL-WORLD: Like a car - you use the steering wheel (public interface),
not directly accessing the engine internals.

DJANGO/FASTAPI: Protecting sensitive data, validation logic.
"""

class BankAccount:
    """Real-world banking example"""
    
    def __init__(self, account_number, owner, balance=0):
        self.account_number = account_number  # Public
        self.owner = owner  # Public
        self.__balance = balance  # Private (name mangling)
        self._transaction_history = []  # Protected
    
    # Getter method (public interface to access private data)
    def get_balance(self):
        """Safe way to check balance"""
        return self.__balance
    
    # Setter with validation
    def deposit(self, amount):
        """Public method with validation"""
        if amount <= 0:
            raise ValueError("Deposit amount must be positive")
        self.__balance += amount
        self._transaction_history.append(f"Deposit: +${amount}")
        return self.__balance
    
    def withdraw(self, amount):
        """Protected operation with business logic"""
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive")
        if amount > self.__balance:
            raise ValueError("Insufficient funds")
        self.__balance -= amount
        self._transaction_history.append(f"Withdrawal: -${amount}")
        return self.__balance
    
    def __str__(self):
        """String representation"""
        return f"Account {self.account_number}: ${self.__balance}"

# Usage
account = BankAccount("ACC001", "Paul Ifemene", 1000)
print(account.get_balance())  # 1000
account.deposit(500)
account.withdraw(200)
print(account)

# Try to access private attribute (will fail properly)
# print(account.__balance)  # AttributeError
# But can access via name mangling (not recommended)
print(account._BankAccount__balance)  # 1300 (shows it's there, but discouraged)


# ==============================================================================
# 5. INHERITANCE - CODE REUSABILITY
# ==============================================================================
"""
CONCEPT: A class can inherit attributes and methods from another class.

TYPES:
1. Single Inheritance: Child inherits from one parent
2. Multiple Inheritance: Child inherits from multiple parents
3. Multilevel Inheritance: Chain of inheritance

REAL-WORLD: Animal -> Mammal -> Dog (each level adds specificity)

DJANGO: All models inherit from models.Model
FASTAPI: Response models inherit from pydantic.BaseModel
"""

# Single Inheritance
class Animal:
    """Base class"""
    
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def make_sound(self):
        return "Some generic sound"
    
    def info(self):
        return f"{self.name} is {self.age} years old"

class Dog(Animal):
    """Derived class - inherits from Animal"""
    
    def __init__(self, name, age, breed):
        super().__init__(name, age)  # Call parent constructor
        self.breed = breed
    
    def make_sound(self):  # Method overriding
        return "Woof! Woof!"
    
    def fetch(self):  # New method specific to Dog
        return f"{self.name} is fetching the ball"

class Cat(Animal):
    """Another derived class"""
    
    def make_sound(self):
        return "Meow!"
    
    def scratch(self):
        return f"{self.name} is scratching"

# Usage
dog = Dog("Buddy", 3, "Golden Retriever")
cat = Cat("Whiskers", 2)

print(dog.info())  # Inherited method
print(dog.make_sound())  # Overridden method
print(dog.fetch())  # New method

print(cat.make_sound())


# Multiple Inheritance
class Flyer:
    """Mixin for flying ability"""
    
    def fly(self):
        return "Flying through the air"

class Swimmer:
    """Mixin for swimming ability"""
    
    def swim(self):
        return "Swimming through water"

class Duck(Animal, Flyer, Swimmer):
    """Duck can do it all!"""
    
    def make_sound(self):
        return "Quack!"

duck = Duck("Donald", 1)
print(duck.make_sound())
print(duck.fly())
print(duck.swim())


# Multilevel Inheritance
class Vehicle:
    """Base class"""
    
    def __init__(self, brand):
        self.brand = brand

class Car(Vehicle):
    """Intermediate class"""
    
    def __init__(self, brand, model):
        super().__init__(brand)
        self.model = model

class ElectricCar(Car):
    """Final derived class"""
    
    def __init__(self, brand, model, battery_capacity):
        super().__init__(brand, model)
        self.battery_capacity = battery_capacity
    
    def info(self):
        return f"{self.brand} {self.model} with {self.battery_capacity}kWh battery"

tesla = ElectricCar("Tesla", "Model 3", 75)
print(tesla.info())


# ==============================================================================
# 6. POLYMORPHISM - MANY FORMS
# ==============================================================================
"""
CONCEPT: Same interface, different implementations.

TYPES:
1. Method Overriding: Child class redefines parent method
2. Duck Typing: "If it walks like a duck and quacks like a duck, it's a duck"

REAL-WORLD: Payment methods - different ways to pay (card, cash, crypto)
but all implement a 'pay' method.

DJANGO/FASTAPI: Serializers, validators, different database backends
"""

class Payment:
    """Base payment class"""
    
    def process_payment(self, amount):
        raise NotImplementedError("Subclasses must implement this")

class CreditCardPayment(Payment):
    """Credit card implementation"""
    
    def __init__(self, card_number, cvv):
        self.card_number = card_number
        self.cvv = cvv
    
    def process_payment(self, amount):
        return f"Processing ${amount} via Credit Card ending in {self.card_number[-4:]}"

class PayPalPayment(Payment):
    """PayPal implementation"""
    
    def __init__(self, email):
        self.email = email
    
    def process_payment(self, amount):
        return f"Processing ${amount} via PayPal account {self.email}"

class CryptoPayment(Payment):
    """Cryptocurrency implementation"""
    
    def __init__(self, wallet_address):
        self.wallet_address = wallet_address
    
    def process_payment(self, amount):
        return f"Processing ${amount} via Crypto wallet {self.wallet_address[:10]}..."

# Polymorphic function - works with any Payment type
def checkout(payment_method, amount):
    """Process payment regardless of payment type"""
    return payment_method.process_payment(amount)

# Usage - same function, different behaviors
credit = CreditCardPayment("1234567890123456", "123")
paypal = PayPalPayment("paul@example.com")
crypto = CryptoPayment("0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb")

print(checkout(credit, 100))
print(checkout(paypal, 50))
print(checkout(crypto, 200))


# Duck Typing Example
class EmailNotification:
    def send(self, message):
        return f"Sending email: {message}"

class SMSNotification:
    def send(self, message):
        return f"Sending SMS: {message}"

class PushNotification:
    def send(self, message):
        return f"Sending push notification: {message}"

def notify_user(notification, message):
    """Doesn't care about the type, just that it has a 'send' method"""
    return notification.send(message)

# All work because they have the 'send' method
print(notify_user(EmailNotification(), "Welcome!"))
print(notify_user(SMSNotification(), "Your code is 1234"))
print(notify_user(PushNotification(), "New message received"))


# ==============================================================================
# 7. ABSTRACTION - HIDING COMPLEXITY
# ==============================================================================
"""
CONCEPT: Showing only essential features, hiding implementation details.

PYTHON: Use ABC (Abstract Base Class) module

REAL-WORLD: You use a TV remote without knowing the circuit details.

DJANGO/FASTAPI: Base views, abstract models, generic handlers
"""

from abc import ABC, abstractmethod

class DatabaseHandler(ABC):
    """Abstract base class - cannot be instantiated"""
    
    @abstractmethod
    def connect(self):
        """Must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def execute_query(self, query):
        """Must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def close(self):
        """Must be implemented by subclasses"""
        pass
    
    # Concrete method (shared implementation)
    def log_query(self, query):
        return f"Logging query: {query}"

class PostgreSQLHandler(DatabaseHandler):
    """Concrete implementation for PostgreSQL"""
    
    def connect(self):
        return "Connected to PostgreSQL"
    
    def execute_query(self, query):
        self.log_query(query)
        return f"Executing in PostgreSQL: {query}"
    
    def close(self):
        return "PostgreSQL connection closed"

class MongoDBHandler(DatabaseHandler):
    """Concrete implementation for MongoDB"""
    
    def connect(self):
        return "Connected to MongoDB"
    
    def execute_query(self, query):
        self.log_query(query)
        return f"Executing in MongoDB: {query}"
    
    def close(self):
        return "MongoDB connection closed"

# Usage
def perform_database_operation(db_handler):
    """Works with any DatabaseHandler implementation"""
    print(db_handler.connect())
    print(db_handler.execute_query("SELECT * FROM users"))
    print(db_handler.close())

postgres = PostgreSQLHandler()
mongo = MongoDBHandler()

perform_database_operation(postgres)
print()
perform_database_operation(mongo)


# ==============================================================================
# 8. SPECIAL METHODS (MAGIC/DUNDER METHODS)
# ==============================================================================
"""
CONCEPT: Methods with double underscores that Python calls automatically.

COMMON ONES:
__init__: Constructor
__str__: String representation (user-friendly)
__repr__: Official representation (developer-friendly)
__len__: len() function
__getitem__: Indexing []
__setitem__: Assignment via indexing
__eq__: Equality ==
__lt__, __gt__: Comparison < >
__add__, __sub__: Arithmetic + -
__call__: Make object callable like a function
__enter__, __exit__: Context manager (with statement)

DJANGO/FASTAPI: Models use these extensively
"""

class Book:
    """Complete book class with magic methods"""
    
    def __init__(self, title, author, pages, price):
        self.title = title
        self.author = author
        self.pages = pages
        self.price = price
    
    def __str__(self):
        """User-friendly string - used by print()"""
        return f"{self.title} by {self.author}"
    
    def __repr__(self):
        """Developer-friendly string - used in debugger"""
        return f"Book('{self.title}', '{self.author}', {self.pages}, {self.price})"
    
    def __len__(self):
        """Return number of pages"""
        return self.pages
    
    def __eq__(self, other):
        """Compare books by title and author"""
        if isinstance(other, Book):
            return self.title == other.title and self.author == other.author
        return False
    
    def __lt__(self, other):
        """Compare books by price"""
        if isinstance(other, Book):
            return self.price < other.price
        return NotImplemented
    
    def __add__(self, other):
        """Add book prices"""
        if isinstance(other, Book):
            return self.price + other.price
        return NotImplemented

# Usage
book1 = Book("Python OOP", "Paul Ifemene", 300, 45.99)
book2 = Book("Django Mastery", "Jane Doe", 450, 55.99)

print(book1)  # Calls __str__
print(repr(book1))  # Calls __repr__
print(f"Pages: {len(book1)}")  # Calls __len__
print(f"Total cost: ${book1 + book2}")  # Calls __add__
print(f"book1 < book2: {book1 < book2}")  # Calls __lt__


class ShoppingCart:
    """Shopping cart with item access"""
    
    def __init__(self):
        self.items = []
    
    def add_item(self, item):
        self.items.append(item)
    
    def __len__(self):
        """Number of items"""
        return len(self.items)
    
    def __getitem__(self, index):
        """Access item by index: cart[0]"""
        return self.items[index]
    
    def __setitem__(self, index, value):
        """Set item by index: cart[0] = new_item"""
        self.items[index] = value
    
    def __iter__(self):
        """Make cart iterable"""
        return iter(self.items)
    
    def __contains__(self, item):
        """Support 'in' operator"""
        return item in self.items

cart = ShoppingCart()
cart.add_item("Laptop")
cart.add_item("Mouse")
cart.add_item("Keyboard")

print(f"Items in cart: {len(cart)}")
print(f"First item: {cart[0]}")  # __getitem__
cart[1] = "Wireless Mouse"  # __setitem__

# Iterate over cart
for item in cart:  # __iter__
    print(f"- {item}")

print(f"'Laptop' in cart: {'Laptop' in cart}")  # __contains__


# Context Manager Example
class FileManager:
    """Custom context manager"""
    
    def __init__(self, filename, mode):
        self.filename = filename
        self.mode = mode
        self.file = None
    
    def __enter__(self):
        """Called when entering 'with' block"""
        self.file = open(self.filename, self.mode)
        return self.file
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Called when exiting 'with' block (even if error)"""
        if self.file:
            self.file.close()
        return False  # Don't suppress exceptions

# Usage (similar to Django database connections)
# with FileManager('test.txt', 'w') as f:
#     f.write('Hello, World!')


# ==============================================================================
# 9. CLASS METHODS AND STATIC METHODS
# ==============================================================================
"""
CONCEPT:
- Instance Method: Needs 'self', works with instance data
- Class Method: Needs 'cls', works with class data, can be alternative constructor
- Static Method: Needs neither, utility function grouped in class

REAL-WORLD: Instance = personal tasks, Class = company-wide tasks, Static = general utilities

DJANGO: Class methods for custom managers, static for utilities
"""

class Employee:
    """Employee management system"""
    
    # Class variable
    company_name = "TechCorp"
    employee_count = 0
    
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        Employee.employee_count += 1
    
    # Instance method
    def give_raise(self, amount):
        """Operates on instance"""
        self.salary += amount
        return self.salary
    
    # Class method - alternative constructor
    @classmethod
    def from_string(cls, emp_str):
        """Create employee from string 'Name-Salary'"""
        name, salary = emp_str.split('-')
        return cls(name, int(salary))
    
    @classmethod
    def set_company_name(cls, name):
        """Modify class variable"""
        cls.company_name = name
    
    @classmethod
    def get_employee_count(cls):
        """Access class variable"""
        return cls.employee_count
    
    # Static method - utility function
    @staticmethod
    def is_valid_salary(salary):
        """Validate salary - doesn't need instance or class"""
        return isinstance(salary, (int, float)) and salary > 0
    
    @staticmethod
    def calculate_tax(salary):
        """Calculate tax - utility function"""
        if salary <= 50000:
            return salary * 0.15
        return salary * 0.25

# Usage
# Instance method
emp1 = Employee("Paul", 50000)
emp1.give_raise(5000)

# Class method as alternative constructor
emp2 = Employee.from_string("Jane-60000")
print(f"{emp2.name} earns ${emp2.salary}")

# Class method to access/modify class data
print(f"Total employees: {Employee.get_employee_count()}")
Employee.set_company_name("NewTech Inc")

# Static methods
print(f"Is 50000 valid? {Employee.is_valid_salary(50000)}")
print(f"Tax on $60000: ${Employee.calculate_tax(60000)}")


# ==============================================================================
# 10. PROPERTY DECORATORS - ELEGANT ENCAPSULATION
# ==============================================================================
"""
CONCEPT: Make methods look like attributes, with getter, setter, deleter.

REAL-WORLD: Temperature conversion - store in Celsius, access as Fahrenheit

DJANGO/FASTAPI: Model properties, computed fields, validation
"""

class Temperature:
    """Temperature with automatic conversion"""
    
    def __init__(self, celsius=0):
        self._celsius = celsius
    
    @property
    def celsius(self):
        """Getter - access like attribute"""
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        """Setter with validation"""
        if value < -273.15:
            raise ValueError("Temperature below absolute zero!")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        """Computed property"""
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        """Set via fahrenheit"""
        self._celsius = (value - 32) * 5/9
    
    @property
    def kelvin(self):
        """Another computed property"""
        return self._celsius + 273.15

# Usage - looks like attributes, but has logic!
temp = Temperature(25)
print(f"Celsius: {temp.celsius}°C")
print(f"Fahrenheit: {temp.fahrenheit}°F")
print(f"Kelvin: {temp.kelvin}K")

temp.fahrenheit = 98.6  # Set via fahrenheit
print(f"Body temp in Celsius: {temp.celsius}°C")


class User:
    """User with validated email"""
    
    def __init__(self, name, email):
        self.name = name
        self._email = None
        self.email = email  # Uses setter
    
    @property
    def email(self):
        """Email getter"""
        return self._email
    
    @email.setter
    def email(self, value):
        """Email setter with validation"""
        if '@' not in value:
            raise ValueError("Invalid email address")
        self._email = value.lower()
    
    @property
    def display_name(self):
        """Computed property"""
        return f"{self.name} <{self.email}>"

user = User("Paul Ifemene", "PAUL@EXAMPLE.COM")
print(user.display_name)  # Paul Ifemene <paul@example.com>


# ==============================================================================
# 11. COMPOSITION VS INHERITANCE
# ==============================================================================
"""
CONCEPT:
- Inheritance: "IS-A" relationship (Dog IS-A Animal)
- Composition: "HAS-A" relationship (Car HAS-A Engine)

RULE: Prefer composition over inheritance when possible (more flexible)

REAL-WORLD: A car HAS-A engine, not IS-A engine

DJANGO/FASTAPI: Models often use composition (ForeignKey, related objects)
"""

# Inheritance approach (tighter coupling)
class ElectricDevice:
    def charge(self):
        return "Charging..."

class Phone(ElectricDevice):
    """Phone IS-A ElectricDevice"""
    pass

class Laptop(ElectricDevice):
    """Laptop IS-A ElectricDevice"""
    pass


# Composition approach (more flexible)
class Battery:
    """Battery component"""
    
    def __init__(self, capacity):
        self.capacity = capacity
        self.charge_level = 100
    
    def use(self, amount):
        self.charge_level = max(0, self.charge_level - amount)
    
    def charge(self):
        self.charge_level = 100
        return f"Battery charged to {self.charge_level}%"

class Camera:
    """Camera component"""
    
    def __init__(self, megapixels):
        self.megapixels = megapixels
    
    def take_photo(self):
        return f"Taking {self.megapixels}MP photo"

class SmartPhone:
    """SmartPhone HAS-A Battery and HAS-A Camera"""
    
    def __init__(self, brand, battery_capacity, camera_mp):
        self.brand = brand
        self.battery = Battery(battery_capacity)  # Composition
        self.camera = Camera(camera_mp)  # Composition
    
    def take_photo(self):
        """Delegate to camera"""
        if self.battery.charge_level > 5:
            self.battery.use(5)
            return self.camera.take_photo()
        return "Battery too low!"
    
    def charge_phone(self):
        """Delegate to battery"""
        return self.battery.charge()

# Usage
phone = SmartPhone("iPhone", 4000, 12)
print(phone.take_photo())
print(f"Battery: {phone.battery.charge_level}%")
print(phone.charge_phone())


# ==============================================================================
# 12. DESIGN PATTERNS FOR DJANGO/FASTAPI
# ==============================================================================
"""
Common patterns you'll use in frameworks:

1. Singleton: One instance only (database connection)
2. Factory: Create objects without specifying exact class
3. Observer: Subscribe to events
4. Strategy: Interchangeable algorithms
5. Decorator: Add functionality dynamically
"""

# Singleton Pattern
class DatabaseConnection:
    """Only one database connection exists"""
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.connection = "Database Connected"
        return cls._instance

db1 = DatabaseConnection()
db2 = DatabaseConnection()
print(db1 is db2)  # True - same instance!


# Factory Pattern
class NotificationFactory:
    """Create notifications based on type"""
    
    @staticmethod
    def create_notification(notification_type):
        if notification_type == "email":
            return EmailNotification()
        elif notification_type == "sms":
            return SMSNotification()
        elif notification_type == "push":
            return PushNotification()
        else:
            raise ValueError(f"Unknown notification type: {notification_type}")

# Usage
notification = NotificationFactory.create_notification("email")
print(notification.send("Hello!"))


# Strategy Pattern (like Django serializers)
class SerializationStrategy(ABC):
    @abstractmethod
    def serialize(self, data):
        pass

class JSONSerializer(SerializationStrategy):
    def serialize(self, data):
        import json
        return json.dumps(data)

class XMLSerializer(SerializationStrategy):
    def serialize(self, data):
        return f"<data>{data}</data>"  # Simplified

class DataExporter:
    """Context that uses a strategy"""
    
    def __init__(self, strategy: SerializationStrategy):
        self.strategy = strategy
    
    def export(self, data):
        return self.strategy.serialize(data)

# Usage - easily swap strategies
data = {"name": "Paul", "age": 20}
exporter = DataExporter(JSONSerializer())
print(exporter.export(data))

exporter.strategy = XMLSerializer()  # Change strategy
print(exporter.export(data))


# ==============================================================================
# PRACTICAL DJANGO-LIKE EXAMPLE
# ==============================================================================
"""
This mimics how Django models work
"""

class Model:
    """Base model class (like Django's models.Model)"""
    
    def save(self):
        """Simulate saving to database"""
        print(f"Saving {self.__class__.__name__} to database...")
        return True
    
    def delete(self):
        """Simulate deleting from database"""
        print(f"Deleting {self.__class__.__name__} from database...")
        return True

class BlogPost(Model):
    """Blog post model (like Django model)"""
    
    def __init__(self, title, content, author):
        self.title = title
        self.content = content
        self.author = author
        self.published = False
    
    def publish(self):
        """Business logic method"""
        self.published = True
        self.save()
        return f"'{self.title}' published!"
    
    def __str__(self):
        return f"{self.title} by {self.author}"
    
    @property
    def excerpt(self):
        """Computed property"""
        return self.content[:100] + "..." if len(self.content) > 100 else self.content

# Usage (very Django-like)
post = BlogPost(
    title="Understanding OOP in Python",
    content="Object-Oriented Programming is a paradigm...",
    author="Paul Ifemene"
)
print(post)
print(post.publish())


# ==============================================================================
# PRACTICAL FASTAPI-LIKE EXAMPLE
# ==============================================================================
"""
This mimics how Pydantic models work in FastAPI
"""

class BaseModel:
    """Base model for validation (like Pydantic)"""
    
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
        self.validate()
    
    def validate(self):
        """Override in subclasses"""
        pass
    
    def dict(self):
        """Return as dictionary"""
        return {k: v for k, v in self.__dict__.items() if not k.startswith('_')}

class UserCreate(BaseModel):
    """User creation model (like FastAPI Pydantic model)"""
    
    def validate(self):
        """Validation logic"""
        if not hasattr(self, 'email') or '@' not in self.email:
            raise ValueError("Invalid email")
        if not hasattr(self, 'password') or len(self.password) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not hasattr(self, 'username') or len(self.username) < 3:
            raise ValueError("Username must be at least 3 characters")

# Usage (very FastAPI-like)
user_data = UserCreate(
    username="paulifemene",
    email="paul@example.com",
    password="securepass123"
)
print(user_data.dict())


print("\n" + "="*70)
print("CONGRATULATIONS! You've covered all major OOP concepts in Python!")
print("="*70)
print("\nNext Steps:")
print("1. Practice building real projects")
print("2. Study Django documentation (models, views, serializers)")
print("3. Study FastAPI documentation (Pydantic models, dependency injection)")
print("4. Build a REST API with FastAPI")
print("5. Build a web app with Django")
