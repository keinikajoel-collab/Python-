
# =============================================================================
#
#   ███████╗████████╗██████╗ ██╗   ██╗ ██████╗████████╗██╗   ██╗██████╗ ███████╗██████╗
#   ██╔════╝╚══██╔══╝██╔══██╗██║   ██║██╔════╝╚══██╔══╝██║   ██║██╔══██╗██╔════╝██╔══██╗
#   ███████╗   ██║   ██████╔╝██║   ██║██║        ██║   ██║   ██║██████╔╝█████╗  ██║  ██║
#   ╚════██║   ██║   ██╔══██╗██║   ██║██║        ██║   ██║   ██║██╔══██╗██╔══╝  ██║  ██║
#   ███████║   ██║   ██║  ██║╚██████╔╝╚██████╗   ██║   ╚██████╔╝██║  ██║███████╗██████╔╝
#   ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝  ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝
#
#                     P R O G R A M M I N G   G U I D E
#
#   A complete beginner's guide to Python — Layers 1 through 4.
#   Written clearly enough for a 12-year-old to understand.
#
#   Created by: Paul Ifemene (Code Buddy Mentor, UCU)
#   For:        BSIT, BSCS & DIT Mentees — Uganda Christian University
#   Purpose:    Structured Programming — Core Concepts
#
#   HOW TO USE THIS FILE:
#   ─────────────────────
#   Read it top to bottom like a book.
#   Run it in your terminal:  python structured_programming_guide.py
#   Each section is clearly labelled and separated.
#   Don't rush — understand each block before moving to the next.
#
# =============================================================================


# We use this to make the output look neat in sections
def section(title):
    print("\n" + "=" * 65)
    print(f"   {title}")
    print("=" * 65)

def sub(title):
    print(f"\n  --- {title} ---")

def show(label, value):
    print(f"  {label}: {value}")


# =============================================================================
#
#   ██╗      █████╗ ██╗   ██╗███████╗██████╗      ██╗
#   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ███║
#   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝    ╚██║
#   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗     ██║
#   ███████╗██║  ██║   ██║   ███████╗██║  ██║     ██║
#   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝     ╚═╝
#
#   DATA — VARIABLES, DATA TYPES, CONSTANTS & OPERATORS
#
# =============================================================================

section("LAYER 1 — DATA: VARIABLES, DATA TYPES & OPERATORS")

# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: What is a Variable?
# ─────────────────────────────────────────────────────────────────────────────
#
# Think of a variable like a labelled box.
# You put something inside the box and give the box a name.
# Whenever you need what's inside, you just use the name.
#
#   [ box called "age" ]  →  contains the number 24
#   [ box called "name" ] →  contains the word "Paul"
#
# In Python, creating a variable looks like this:
#   variable_name = value
#
# The "=" sign does NOT mean "equal to" like in maths.
# It means "put this value INTO this box (variable)".

sub("EXAMPLE 1.1 — Creating and Using Variables")

name = "Alice"           # A box called "name" holding the text "Alice"
age  = 17               # A box called "age" holding the number 17
city = "Kampala"        # A box called "city" holding the text "Kampala"

print("My name is:", name)
print("I am", age, "years old")
print("I live in", city)

# You can CHANGE what's in the box at any time
age = 24                # We updated the box — it now holds 24 instead of 17
print("On my birthday, I turned:", age)


sub("EXAMPLE 1.2 — Variables Can Hold Different Kinds of Information")

student_name    = "Brian"       # text (called a String)
student_number  = 24            # whole number (called an Integer)
gpa             = 4.85          # decimal number (called a Float)
is_enrolled     = True          # yes/no value (called a Boolean)

print("\nStudent Profile:")
print("  Name:    ", student_name)
print("  Number:  ", student_number)
print("  GPA:     ", gpa)
print("  Enrolled:", is_enrolled)


sub("EXAMPLE 1.3 — Variable Naming Rules")

# GOOD variable names — clear and readable
first_name   = "Sarah"     # use underscores to separate words
total_score  = 95
is_passing   = True

# BAD variable names — confusing and unclear
# x = "Sarah"            # what is x? nobody knows
# ts = 95                # what is ts?
# ip = True              # what is ip?

# ✅ RULE: Name your variables so that someone else can READ your code
#          like a sentence.

print("First Name:", first_name)
print("Total Score:", total_score)
print("Is Passing:", is_passing)


sub("EXAMPLE 1.4 — Swapping Variables")

# Let's say you want to swap the values in two boxes.
# You need a THIRD box (temporary) to hold one value while you swap.

drink_a = "Water"
drink_b = "Juice"

print("\nBefore swap:")
print("  drink_a =", drink_a)   # Water
print("  drink_b =", drink_b)   # Juice

# Swap them
temp    = drink_a   # save drink_a in a temporary box
drink_a = drink_b   # pour drink_b into drink_a
drink_b = temp      # pour the saved value into drink_b

print("After swap:")
print("  drink_a =", drink_a)   # Juice
print("  drink_b =", drink_b)   # Water

# Python also has a shortcut for this:
drink_a, drink_b = drink_b, drink_a   # swaps back in one line!
print("After swapping back:")
print("  drink_a =", drink_a)
print("  drink_b =", drink_b)


# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: Data Types
# ─────────────────────────────────────────────────────────────────────────────
#
# Every variable has a TYPE — the kind of data it holds.
# Python has 4 basic data types you must know:
#
#   Type       | Example          | What it's for
#   -----------|------------------|------------------------------
#   int        | 5, -3, 100       | Whole numbers (no decimal)
#   float      | 3.14, -0.5       | Numbers with a decimal point
#   str        | "hello", "UCU"   | Text (always in quotes)
#   bool       | True, False      | Yes/No, On/Off decisions
#
# Python tells you the type using the type() function.

section("LAYER 1 CONTINUED — DATA TYPES IN DEPTH")

sub("EXAMPLE 1.5 — The Four Basic Data Types")

my_integer = 42
my_float   = 3.14159
my_string  = "Hello, Uganda!"
my_boolean = True

print("Value:", my_integer, "  →  Type:", type(my_integer))
print("Value:", my_float,   "  →  Type:", type(my_float))
print("Value:", my_string,  "  →  Type:", type(my_string))
print("Value:", my_boolean, "  →  Type:", type(my_boolean))

# type() outputs things like <class 'int'>
# 'int' means integer, 'str' means string, 'float' means float, 'bool' means boolean


sub("EXAMPLE 1.6 — Strings (Text) in Detail")

# Strings are just text. They live inside quotes (" " or ' ')
greeting   = "Good morning"
name       = 'Mukasa'

# You can JOIN strings together using + (called concatenation)
full_greeting = greeting + ", " + name + "!"
print(full_greeting)   # Good morning, Mukasa!

# You can find the LENGTH of a string using len()
word = "University"
print("The word has", len(word), "letters")   # 10

# You can access individual letters using their POSITION (index)
# Positions start at 0, not 1 — this trips up many beginners!
#
#   U  n  i  v  e  r  s  i  t  y
#   0  1  2  3  4  5  6  7  8  9
#
print("First letter:", word[0])    # U
print("Last letter: ", word[-1])   # y   (-1 means "the last one")

# You can also REPEAT a string
line = "-" * 20
print(line)   # --------------------


sub("EXAMPLE 1.7 — Integers vs Floats (Numbers)")

apples = 5          # int — whole number
price  = 1.50       # float — has a decimal

total = apples * price
print("Apples:", apples)
print("Price per apple: UGX", price)
print("Total cost: UGX", total)

# Dividing two integers in Python ALWAYS gives a float
result1 = 7 / 2
print("\n7 divided by 2 =", result1)      # 3.5 (float)

# If you want ONLY the whole number part, use // (floor division)
result2 = 7 // 2
print("7 floor-divided by 2 =", result2)  # 3 (int)

# The remainder after division uses % (called modulo)
result3 = 7 % 2
print("7 mod 2 (remainder) =", result3)   # 1


sub("EXAMPLE 1.8 — Type Conversion (Changing a Type)")

# Sometimes you get a number stored as text and need to do maths with it.
# You can CONVERT between types using int(), float(), str()

age_as_text   = "20"           # this is a string — you can't add to it
age_as_number = int(age_as_text)  # now it's a real integer

print("Type before:", type(age_as_text))    # str
print("Type after: ", type(age_as_number))  # int
print("In 5 years you'll be:", age_as_number + 5)

# float to int chops off the decimal (does NOT round)
height = 5.9
print("\nHeight as float:", height)
print("Height as int:  ", int(height))   # 5 (not 6!)

# number to string — useful when you want to JOIN a number to text
score = 85
message = "Your score is: " + str(score) + " out of 100"
print(message)


# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: Constants
# ─────────────────────────────────────────────────────────────────────────────
#
# A constant is a variable whose value NEVER changes throughout the program.
# Python doesn't enforce this — it's a CONVENTION (a rule programmers follow).
# By writing the name in ALL_CAPS, you're telling everyone:
# "Don't change this value!"

section("LAYER 1 CONTINUED — CONSTANTS")

sub("EXAMPLE 1.9 — Using Constants")

# These values should never change in our program
PI              = 3.14159
MAX_STUDENTS    = 40
SCHOOL_NAME     = "Uganda Christian University"
PASSING_GRADE   = 50

radius = 7
area_of_circle = PI * radius * radius

print("School:", SCHOOL_NAME)
print("Max class size:", MAX_STUDENTS)
print("Passing grade:", PASSING_GRADE, "%")
print("Area of circle with radius", radius, "=", area_of_circle)


# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: Operators
# ─────────────────────────────────────────────────────────────────────────────
#
# Operators are special symbols that DO something to values.
# There are 4 groups you must know:
#
#   1. Arithmetic  — do maths        (+, -, *, /, //, %, **)
#   2. Assignment  — store values    (=, +=, -=, *=, /=)
#   3. Comparison  — compare values  (==, !=, >, <, >=, <=)
#   4. Logical     — combine yes/no  (and, or, not)

section("LAYER 1 CONTINUED — OPERATORS")

sub("EXAMPLE 1.10 — Arithmetic Operators")

a = 10
b = 3

print("a =", a, "  b =", b)
print()
print("a + b  =", a + b)     # Addition       → 13
print("a - b  =", a - b)     # Subtraction    → 7
print("a * b  =", a * b)     # Multiplication → 30
print("a / b  =", a / b)     # Division       → 3.333...
print("a // b =", a // b)    # Floor Division → 3  (no decimal)
print("a % b  =", a % b)     # Modulo         → 1  (remainder)
print("a ** b =", a ** b)    # Exponent       → 1000 (10³)


sub("EXAMPLE 1.11 — Assignment Operators (Shorthand Updating)")

score = 100
print("Starting score:", score)

score += 10    # same as: score = score + 10
print("After bonus (+10):", score)

score -= 5     # same as: score = score - 5
print("After penalty (-5):", score)

score *= 2     # same as: score = score * 2
print("After doubling (*2):", score)

score //= 3    # same as: score = score // 3
print("After dividing by 3 (//3):", score)


sub("EXAMPLE 1.12 — Comparison Operators (Always Return True or False)")

x = 10
y = 20

print("x =", x, "  y =", y)
print()
print("x == y  (x equals y?)        →", x == y)     # False
print("x != y  (x not equal to y?)  →", x != y)     # True
print("x > y   (x greater than y?)  →", x > y)      # False
print("x < y   (x less than y?)     →", x < y)      # True
print("x >= 10 (x at least 10?)     →", x >= 10)    # True
print("x <= 9  (x at most 9?)       →", x <= 9)     # False

# ⚠️  COMMON MISTAKE:
#    = is for ASSIGNING (putting a value in a box)
#    == is for COMPARING (asking "are these the same?")
#    They are NOT the same thing!


sub("EXAMPLE 1.13 — Logical Operators (Combining True/False)")

# and → True ONLY if BOTH sides are True
# or  → True if AT LEAST ONE side is True
# not → flips True to False, and False to True

is_student = True
has_id_card = False

print("is_student  :", is_student)
print("has_id_card :", has_id_card)
print()

# Can they enter the library?
can_enter = is_student and has_id_card
print("Can enter library? (student AND has ID):", can_enter)   # False

# Can they get a discount?
can_discount = is_student or has_id_card
print("Can get discount? (student OR has ID):", can_discount)  # True

# Are they NOT a student?
print("Is NOT a student:", not is_student)   # False

# Real-world example: access to exam hall
has_paid_fees   = True
registered      = True
has_been_barred = False

can_sit_exam = has_paid_fees and registered and (not has_been_barred)
print("\nCan sit exam?", can_sit_exam)   # True


# =============================================================================
#
#   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██████╗
#   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ╚════██╗
#   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝     █████╔╝
#   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ██╔═══╝
#   ███████╗██║  ██║   ██║   ███████╗██║  ██║    ███████╗
#   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚══════╝
#
#   INPUT & OUTPUT
#
# =============================================================================

section("LAYER 2 — INPUT & OUTPUT")

# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: Output with print()
# ─────────────────────────────────────────────────────────────────────────────
#
# print() shows text or values on the screen.
# It's how your program "talks" to the user.

sub("EXAMPLE 2.1 — Different Ways to Use print()")

# Basic printing
print("Hello, World!")

# Printing multiple things separated by commas
print("Name:", "Grace", "  Age:", 20)

# Printing with a custom separator
print("Uganda", "Kenya", "Tanzania", sep=" | ")

# Printing without moving to a new line (end=" " stays on the same line)
print("Loading", end=" ")
print(".", end=" ")
print(".", end=" ")
print(". Done!")

# Printing a blank line
print()


sub("EXAMPLE 2.2 — f-strings (The BEST way to format output)")

# f-strings let you put variables DIRECTLY inside a string.
# Just put f before the quote, then use {variable} inside.

student = "Tendo"
score   = 78
grade   = "B+"

print(f"Student Name : {student}")
print(f"Exam Score   : {score}/100")
print(f"Final Grade  : {grade}")

# You can even do calculations inside the {}
items = 3
price = 2500
print(f"Total cost: UGX {items * price:,}")   # :, adds comma formatting


sub("EXAMPLE 2.3 — Getting Input from the User with input()")

# input() PAUSES the program and waits for the user to type something.
# Whatever they type comes back as a STRING.

# ⚠️  NOTE: We're not calling input() here because this is a demo file.
#    But here's EXACTLY how you'd write it in your own program:

# ----- TEMPLATE (copy this into your own file) -----
#
#   name = input("What is your name? ")
#   print("Hello,", name + "!")
#
# ---------------------------------------------------

# To show you how it WOULD work, we simulate it here:
simulated_name  = "Gladys"     # pretend the user typed this
simulated_age   = "21"         # input() always returns a STRING

print(f"\n[Simulated] User typed name: {simulated_name}")
print(f"[Simulated] User typed age:  {simulated_age}")
print(f"[Simulated] Type of age:     {type(simulated_age)}")  # str!

# ⚠️  If you want to do MATHS with a number the user typed,
#     you MUST convert it first using int() or float()
age_as_number = int(simulated_age)
print(f"[Simulated] Age next year:   {age_as_number + 1}")


sub("EXAMPLE 2.4 — Formatting Output Neatly")

# Using .format() for aligned columns
print("\n{:<15} {:<10} {:<10}".format("Name", "Score", "Grade"))
print("-" * 35)
print("{:<15} {:<10} {:<10}".format("Alice Namukasa", 92, "A"))
print("{:<15} {:<10} {:<10}".format("Bob Ssemwanga", 74, "B"))
print("{:<15} {:<10} {:<10}".format("Carol Tendo",   55, "C"))
print("{:<15} {:<10} {:<10}".format("David Mukisa",  40, "F"))

# {:<15} means: left-align, take up 15 spaces
# This creates a neat table without any extra libraries


# =============================================================================
#
#   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██████╗
#   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ╚════██╗
#   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝      ███╔╝
#   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ██╔══╝
#   ███████╗██║  ██║   ██║   ███████╗██║  ██║    ███████╗
#   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚══════╝
#
#   CONTROL FLOW — DECISIONS (if / elif / else)
#
# =============================================================================

section("LAYER 3 — CONTROL FLOW: DECISIONS (if / elif / else)")

# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: What is an if-statement?
# ─────────────────────────────────────────────────────────────────────────────
#
# An if-statement lets your program MAKE DECISIONS.
# It asks a question (condition), and if the answer is True, it runs some code.
# If the answer is False, it skips that code.
#
# Structure:
#
#   if (condition is True):
#       do this thing
#   elif (another condition is True):
#       do this other thing
#   else:
#       do this if nothing above was True
#
# ⚠️  INDENTATION IS CRITICAL IN PYTHON!
#     The code INSIDE an if-block MUST be indented (pushed to the right).
#     Use 4 spaces (or Tab). Python uses this to know what's "inside" the if.


sub("EXAMPLE 3.1 — Basic if / else")

temperature = 35   # degrees Celsius

if temperature > 30:
    # This line only runs if temperature is greater than 30
    print("It is HOT outside! Stay hydrated.")
else:
    # This line only runs if temperature is NOT greater than 30
    print("The weather is pleasant today.")

# Change temperature to 22 and re-run — you'll see the other message!


sub("EXAMPLE 3.2 — if / elif / else (Multiple Choices)")

# Grading system
exam_score = 72

if exam_score >= 90:
    grade = "A"
    remark = "Distinction — Excellent work!"
elif exam_score >= 80:
    grade = "B+"
    remark = "Credit — Very good!"
elif exam_score >= 70:
    grade = "B"
    remark = "Credit — Good work"
elif exam_score >= 60:
    grade = "C"
    remark = "Pass — Keep pushing"
elif exam_score >= 50:
    grade = "D"
    remark = "Pass — You can do better"
else:
    grade = "F"
    remark = "Fail — Please see your lecturer"

print(f"Score : {exam_score}/100")
print(f"Grade : {grade}")
print(f"Remark: {remark}")


sub("EXAMPLE 3.3 — Nested if-statements (if inside an if)")

# Nested means one if-statement is INSIDE another.
# Think of it like a security checkpoint:
#   First check 1 → if you pass, proceed to check 2.

age           = 20
has_student_id = True

if age >= 18:
    print("Age check: PASSED")

    if has_student_id:
        print("ID check: PASSED")
        print("✅ You may enter the exam hall.")
    else:
        print("ID check: FAILED")
        print("❌ Please get your student ID before entering.")
else:
    print("Age check: FAILED")
    print("❌ You must be at least 18 to take this exam.")

# Notice the indentation levels:
# - outer if block: 1 level in (4 spaces)
# - inner if block: 2 levels in (8 spaces)


sub("EXAMPLE 3.4 — Combining Conditions with 'and' / 'or'")

# Instead of nesting, you can sometimes combine conditions in ONE if.

username = "admin"
password = "ucuSecure2024"

# Both must be correct to log in
if username == "admin" and password == "ucuSecure2024":
    print("✅ Login successful! Welcome, Admin.")
else:
    print("❌ Incorrect username or password.")

print()

# Checking if a number is in a valid range
student_age = 22
if student_age >= 16 and student_age <= 35:
    print(f"Age {student_age} is valid for student registration.")
else:
    print(f"Age {student_age} is outside the allowed range.")

print()

# Checking if a day is a weekend
day = "Saturday"
if day == "Saturday" or day == "Sunday":
    print(f"{day} is a weekend — no lectures!")
else:
    print(f"{day} is a weekday — attend your classes!")


sub("EXAMPLE 3.5 — The One-Line Shortcut (Ternary / Conditional Expression)")

# Python lets you write a simple if/else in ONE line.
# Format:  value_if_true  if  condition  else  value_if_false

marks = 55
result = "PASS" if marks >= 50 else "FAIL"
print(f"Marks: {marks}  →  Result: {result}")

# Another example:
number = -7
sign = "positive" if number > 0 else "negative or zero"
print(f"{number} is {sign}")


sub("EXAMPLE 3.6 — Real-World Example: Internet Billing")

# Calculate a monthly internet bill based on data usage
data_used_gb = 45

if data_used_gb <= 10:
    plan     = "Basic"
    bill_ugx = 50_000
elif data_used_gb <= 30:
    plan     = "Standard"
    bill_ugx = 120_000
elif data_used_gb <= 60:
    plan     = "Premium"
    bill_ugx = 200_000
else:
    plan     = "Unlimited"
    bill_ugx = 350_000

print(f"Data used   : {data_used_gb} GB")
print(f"Plan        : {plan}")
print(f"Monthly bill: UGX {bill_ugx:,}")


# =============================================================================
#
#   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██╗  ██╗
#   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ██║  ██║
#   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝    ███████║
#   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ╚════██║
#   ███████╗██║  ██║   ██║   ███████╗██║  ██║         ██║
#   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝         ╚═╝
#
#   CONTROL FLOW — REPETITION (Loops: while, for, break, continue)
#
# =============================================================================

section("LAYER 4 — CONTROL FLOW: LOOPS (Repetition)")

# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: What is a Loop?
# ─────────────────────────────────────────────────────────────────────────────
#
# A loop lets you run the SAME block of code MULTIPLE TIMES
# without writing it out over and over.
#
# Imagine you want to print "Good morning!" 100 times.
# Without a loop, you'd write print() 100 times. Very bad.
# With a loop, you write it ONCE and tell it to repeat.
#
# Python has two kinds of loops:
#   1. while loop — keeps going AS LONG AS a condition is True
#   2. for loop   — repeats a specific NUMBER of times (or over a list)


# ─────────────────────────────────────────────────────────────────────────────
# THE WHILE LOOP
# ─────────────────────────────────────────────────────────────────────────────
#
# Structure:
#   while (condition is True):
#       do this
#       (update something so the condition eventually becomes False)
#
# ⚠️  WARNING: If the condition NEVER becomes False, the loop runs forever.
#     This is called an INFINITE LOOP and will freeze your program.
#     Always make sure something inside the loop moves you toward False.

sub("EXAMPLE 4.1 — Basic while Loop (Counting Up)")

count = 1

while count <= 5:
    # This block runs again and again as long as count is <= 5
    print(f"  Count is: {count}")
    count += 1   # ← This is CRITICAL. Without it, we'd be stuck at 1 forever.

print("  Loop finished!\n")


sub("EXAMPLE 4.2 — while Loop (Countdown)")

rocket = 10

print("  Rocket launch countdown:")
while rocket >= 1:
    print(f"  T-minus {rocket}...")
    rocket -= 1   # decrease by 1 each time

print("  🚀 LIFT OFF!\n")


sub("EXAMPLE 4.3 — while Loop with User Input (Simulated)")

# In a real program, you'd use input() to get the user's guess.
# Here we simulate it with a list of guesses.

secret_number  = 7
simulated_guesses = [3, 9, 1, 7]   # pretend the user typed these one by one
attempt        = 0
found          = False

print("  [Game] Guess the secret number between 1 and 10!")
while attempt < len(simulated_guesses):
    guess = simulated_guesses[attempt]
    attempt += 1
    print(f"  Guess #{attempt}: {guess}", end="  →  ")

    if guess == secret_number:
        print(f"✅ Correct! You got it in {attempt} tries!")
        found = True
        break   # exit the loop immediately — we found it!
    elif guess < secret_number:
        print("Too low! Try higher.")
    else:
        print("Too high! Try lower.")

if not found:
    print(f"  ❌ Out of guesses. The number was {secret_number}.")


sub("EXAMPLE 4.4 — while Loop: Summing Numbers")

# Add all numbers from 1 to 100 (without typing them all out!)
total     = 0
current   = 1

while current <= 100:
    total  += current   # add current number to running total
    current += 1        # move to the next number

# Fun fact: the answer is always n*(n+1)/2
print(f"  Sum of 1 to 100 = {total}")   # 5050


# ─────────────────────────────────────────────────────────────────────────────
# THE FOR LOOP
# ─────────────────────────────────────────────────────────────────────────────
#
# The for loop is used when you know EXACTLY how many times to repeat,
# OR when you want to go through each item in a collection.
#
# Structure:
#   for variable in collection:
#       do this
#
# range(n)        → gives you numbers from 0 up to (but not including) n
# range(a, b)     → gives you numbers from a up to (but not including) b
# range(a, b, c)  → gives you numbers from a to b, stepping by c

sub("EXAMPLE 4.5 — Basic for Loop with range()")

print("  Counting from 0 to 4:")
for i in range(5):      # range(5) → 0, 1, 2, 3, 4
    print(f"    i = {i}")

print()
print("  Counting from 1 to 5:")
for i in range(1, 6):   # range(1, 6) → 1, 2, 3, 4, 5
    print(f"    i = {i}")


sub("EXAMPLE 4.6 — for Loop Stepping by 2 (Even Numbers Only)")

print("  Even numbers from 0 to 20:")
for n in range(0, 21, 2):   # step = 2 → skip every other number
    print(f"    {n}", end=" ")
print()

print("  Odd numbers from 1 to 19:")
for n in range(1, 20, 2):   # step = 2, starting at 1
    print(f"    {n}", end=" ")
print()

print("  Countdown from 10 to 1:")
for n in range(10, 0, -1):  # step = -1 → count backwards
    print(f"    {n}", end=" ")
print()


sub("EXAMPLE 4.7 — for Loop Over a List of Items")

# A list is just a collection of items in order.
# We'll cover lists properly in Layer 6, but you can use them with for now.

fruits = ["mango", "jackfruit", "avocado", "passion fruit", "banana"]

print("  My favourite Ugandan fruits:")
for fruit in fruits:
    print(f"    - {fruit}")

# You can also loop over each character in a string
print()
word = "PYTHON"
print("  Letters in the word PYTHON:")
for letter in word:
    print(f"    [{letter}]", end=" ")
print()


sub("EXAMPLE 4.8 — Nested Loops (A Loop Inside a Loop)")

# Nested loops: the INNER loop completes ALL its repetitions
# for EACH single repetition of the OUTER loop.
#
# Think of it like a clock:
#   For every 1 hour that passes (outer loop),
#   the minutes hand goes through all 60 minutes (inner loop).

print("  Multiplication table (3x3):")
print()
print("  ", end="")
for col in range(1, 4):
    print(f"   × {col}", end="")
print()
print("  " + "─" * 20)

for row in range(1, 4):
    print(f"  {row} |", end="")
    for col in range(1, 4):
        product = row * col
        print(f"  {product:3}", end="")   # :3 means take up 3 spaces
    print()   # move to next line after each row

print()
print("  Star pattern using nested loops:")
for row in range(1, 6):       # outer loop: controls the row (line)
    for col in range(row):    # inner loop: prints 'row' number of stars
        print("*", end=" ")
    print()   # new line after each row


# ─────────────────────────────────────────────────────────────────────────────
# CONCEPT: break and continue
# ─────────────────────────────────────────────────────────────────────────────
#
# break    → immediately EXIT the loop (stop everything)
# continue → SKIP the rest of this one iteration and go to the next

sub("EXAMPLE 4.9 — break: Stopping a Loop Early")

print("  Searching for the first even number divisible by 3:")
for n in range(1, 50):
    if n % 2 == 0 and n % 3 == 0:
        print(f"  Found it: {n}")
        break   # stop searching — we found what we needed
    print(f"  Checked {n} — not it")

print()
print("  Security gate — stop after 3 failed attempts:")
passwords_tried = ["wrong1", "wrong2", "wrongAgain", "correct123"]
attempts = 0

for pwd in passwords_tried:
    if attempts >= 3:
        print("  ❌ Too many failed attempts. System locked.")
        break
    if pwd == "correct123":
        print(f"  ✅ Access granted with password: {pwd}")
        break
    else:
        attempts += 1
        print(f"  ❌ Wrong password: {pwd} (attempt {attempts})")


sub("EXAMPLE 4.10 — continue: Skipping One Iteration")

print("  Printing only ODD numbers (skip even ones):")
for n in range(1, 11):
    if n % 2 == 0:
        continue   # skip even numbers — go back to the top of the loop
    print(f"  {n}", end=" ")
print()

print()
print("  Student list — skip absent students:")
students = [
    ("Alice",   "present"),
    ("Bob",     "absent"),
    ("Carol",   "present"),
    ("David",   "absent"),
    ("Eve",     "present"),
]

print("  Marking attendance:")
for name, status in students:
    if status == "absent":
        print(f"  ⚠️  {name} is absent — skipping")
        continue   # skip the marking step for absent students
    print(f"  ✅ {name} — marked present")


sub("EXAMPLE 4.11 — Real-World Loop: Processing a List of Scores")

scores = [88, 45, 72, 91, 38, 67, 55, 80, 29, 77]

total     = 0
passed    = 0
failed    = 0
highest   = scores[0]   # start by assuming first score is highest
lowest    = scores[0]   # start by assuming first score is lowest

print("  Processing exam scores...")
print()

for score in scores:
    total += score   # add to running total

    if score >= 50:
        passed += 1
        status = "PASS"
    else:
        failed += 1
        status = "FAIL"

    if score > highest:
        highest = score

    if score < lowest:
        lowest = score

    print(f"  Score: {score:3}  →  {status}")

average = total / len(scores)

print()
print("  ─── Summary ───────────────────────")
print(f"  Total students  : {len(scores)}")
print(f"  Passed          : {passed}")
print(f"  Failed          : {failed}")
print(f"  Highest score   : {highest}")
print(f"  Lowest score    : {lowest}")
print(f"  Average score   : {average:.1f}")   # :.1f means 1 decimal place


sub("EXAMPLE 4.12 — FizzBuzz (Classic Programming Exercise)")

# FizzBuzz rules:
#   - Print "Fizz" if the number is divisible by 3
#   - Print "Buzz" if the number is divisible by 5
#   - Print "FizzBuzz" if divisible by BOTH 3 and 5
#   - Otherwise, print the number itself
#
# ⚠️  ORDER MATTERS: check "both" (FizzBuzz) FIRST, before checking each alone

print("  FizzBuzz from 1 to 30:")
print()

for n in range(1, 31):
    if n % 3 == 0 and n % 5 == 0:   # check BOTH first
        print(f"  {n:2} → FizzBuzz")
    elif n % 3 == 0:
        print(f"  {n:2} → Fizz")
    elif n % 5 == 0:
        print(f"  {n:2} → Buzz")
    else:
        print(f"  {n:2} → {n}")


# =============================================================================
#
#   ███████╗███╗   ██╗██████╗
#   ██╔════╝████╗  ██║██╔══██╗
#   █████╗  ██╔██╗ ██║██║  ██║
#   ██╔══╝  ██║╚██╗██║██║  ██║
#   ███████╗██║ ╚████║██████╔╝
#   ╚══════╝╚═╝  ╚═══╝╚═════╝
#
# =============================================================================

section("SUMMARY — WHAT YOU HAVE LEARNED")

print("""
  LAYER 1 — DATA
  ├── Variables    : Labelled boxes that hold values
  ├── Data Types   : int, float, str, bool
  ├── Constants    : Values written in ALL_CAPS that never change
  └── Operators    : Arithmetic, Assignment, Comparison, Logical

  LAYER 2 — INPUT & OUTPUT
  ├── print()      : Showing information to the user
  ├── input()      : Reading information from the user
  ├── f-strings    : The cleanest way to format output
  └── Type casting : Converting user input (str → int, etc.)

  LAYER 3 — DECISIONS (if / elif / else)
  ├── if           : Run code only if condition is True
  ├── elif         : Check another condition if the first was False
  ├── else         : Run if ALL conditions above were False
  ├── Nesting      : Putting an if inside another if
  └── Combining    : Using 'and' / 'or' to test multiple conditions

  LAYER 4 — LOOPS (Repetition)
  ├── while loop   : Repeat AS LONG AS condition is True
  ├── for loop     : Repeat a set number of times (range) or over items
  ├── Nested loops : A loop inside a loop (tables, patterns)
  ├── break        : Exit the loop immediately
  └── continue     : Skip this iteration, go to the next

  ─────────────────────────────────────────────────────────────
  NEXT UP: Layer 5 → Functions (the most important layer!)
  ─────────────────────────────────────────────────────────────

  Remember: Programming is not about memorising syntax.
  It is about learning to THINK in steps.
  Read every example. Change the values. Break things.
  That is how you truly learn.

  — Paul Ifemene, Code Buddy Mentor, UCU 2026
""")

# =============================================================================
#   END OF FILE
# =============================================================================
