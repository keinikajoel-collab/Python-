
/* =============================================================================
 *
 *   ███████╗████████╗██████╗ ██╗   ██╗ ██████╗████████╗██╗   ██╗██████╗ ███████╗██████╗
 *   ██╔════╝╚══██╔══╝██╔══██╗██║   ██║██╔════╝╚══██╔══╝██║   ██║██╔══██╗██╔════╝██╔══██╗
 *   ███████╗   ██║   ██████╔╝██║   ██║██║        ██║   ██║   ██║██████╔╝█████╗  ██║  ██║
 *   ╚════██║   ██║   ██╔══██╗██║   ██║██║        ██║   ██║   ██║██╔══██╗██╔══╝  ██║  ██║
 *   ███████║   ██║   ██║  ██║╚██████╔╝╚██████╗   ██║   ╚██████╔╝██║  ██║███████╗██████╔╝
 *   ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝  ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝
 *
 *                     P R O G R A M M I N G   G U I D E
 *                           [ C   L A N G U A G E ]
 *
 *   A complete beginner's guide to C — Layers 1 through 4.
 *   Written clearly enough for a 12-year-old to understand.
 *
 *   Created by: Paul Ifemene (Code Buddy Mentor, UCU)
 *   For:        BSIT, BSCS & DIT Mentees — Uganda Christian University
 *   Purpose:    Structured Programming — Core Concepts
 *
 *   HOW TO COMPILE AND RUN THIS FILE:
 *   ──────────────────────────────────
 *   Step 1 — Compile:   gcc structured_programming_guide.c -o guide
 *   Step 2 — Run:       ./guide          (on Linux/Mac)
 *                       guide.exe        (on Windows)
 *
 *   Read it top to bottom like a book.
 *   Each section is clearly labelled and separated.
 *   Don't rush — understand each block before moving to the next.
 *
 *   C vs Python — Key Differences You Will Notice:
 *   ────────────────────────────────────────────────
 *   1. Every C file needs  #include <stdio.h>  at the top (loads print/scan)
 *   2. All code lives inside functions. Execution starts at  main()
 *   3. Every variable MUST declare its type before use:  int age = 17;
 *   4. Every statement ends with a semicolon  ;
 *   5. Blocks of code use curly braces  { }  instead of indentation
 *   6. C has no built-in boolean — use  int  (0 = false, 1 = true)
 *   7. Strings in C are arrays of characters, not a simple type
 *   8. printf() is used for output,  scanf() for input
 *
 * =============================================================================
 */

#include <stdio.h>    /* printf(), scanf() — input and output             */
#include <string.h>   /* strlen(), strcpy(), strcat() — string operations  */

/* ─────────────────────────────────────────────────────────────────────────────
 * Helper functions to print neat section headers (same as Python version)
 * ───────────────────────────────────────────────────────────────────────────*/

void section(const char *title) {
    printf("\n=================================================================\n");
    printf("   %s\n", title);
    printf("=================================================================\n");
}

void sub(const char *title) {
    printf("\n  --- %s ---\n", title);
}


/* =============================================================================
 *
 *   ██╗      █████╗ ██╗   ██╗███████╗██████╗      ██╗
 *   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ███║
 *   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝    ╚██║
 *   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗     ██║
 *   ███████╗██║  ██║   ██║   ███████╗██║  ██║     ██║
 *   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝     ╚═╝
 *
 *   DATA — VARIABLES, DATA TYPES, CONSTANTS & OPERATORS
 *
 * =============================================================================
 */

void layer1_variables() {

    section("LAYER 1 — DATA: VARIABLES, DATA TYPES & OPERATORS");

    /* ─────────────────────────────────────────────────────────────────────────
     * CONCEPT: What is a Variable?
     * ─────────────────────────────────────────────────────────────────────────
     *
     * Think of a variable like a labelled box.
     * You put something inside the box and give the box a name.
     * Whenever you need what's inside, you just use the name.
     *
     *   [ box called "age" ]  →  contains the number 17
     *   [ box called "name" ] →  contains the word "Alice"
     *
     * In C, creating a variable looks like this:
     *   type  variable_name = value;
     *
     * ⚠️  IMPORTANT C RULE: You MUST say what TYPE the box holds FIRST.
     *     Python figures out the type automatically. C does NOT.
     *     You have to be explicit:
     *       int age = 17;          (int = whole number box)
     *       char name[] = "Alice"; (char array = text box)
     *
     * The "=" sign does NOT mean "equal to" like in maths.
     * It means "put this value INTO this box (variable)".
     */

    sub("EXAMPLE 1.1 — Creating and Using Variables");

    /* In C, strings are stored as arrays of characters (char[]).
     * The number in brackets [] is the maximum size of the text.
     * Always make it a bit bigger than what you need.           */
    char name[20] = "Alice";    /* A box called "name" holding the text "Alice"  */
    int  age      = 17;         /* A box called "age" holding the number 17      */
    char city[20] = "Kampala";  /* A box called "city" holding the text "Kampala"*/

    /* printf() works like Python's print(), but you use FORMAT SPECIFIERS:
     *   %s  →  for strings (text)
     *   %d  →  for integers (whole numbers)
     *   %f  →  for floats (decimal numbers)
     *   \n  →  means "new line" (like pressing Enter)             */
    printf("My name is: %s\n", name);
    printf("I am %d years old\n", age);
    printf("I live in %s\n", city);

    /* You can CHANGE what's in the box at any time */
    age = 18;    /* Updated the box — it now holds 18 instead of 17 */
    printf("On my birthday, I turned: %d\n", age);


    sub("EXAMPLE 1.2 — Variables Can Hold Different Kinds of Information");

    /* ⚠️  C KEY POINT: Every variable must declare its TYPE first.
     *
     *   Type       | Declaration         | What it holds
     *   -----------|---------------------|------------------------------
     *   int        | int x = 5;          | Whole numbers (no decimal)
     *   float      | float x = 3.14;     | Decimal numbers (less precise)
     *   double     | double x = 3.14159; | Decimal numbers (more precise)
     *   char       | char x = 'A';       | A single character
     *   char[]     | char x[] = "hello"; | A string (text)
     *   int (bool) | int x = 1;          | 1 = true, 0 = false
     */

    char   student_name[20]  = "Brian";  /* text (stored as char array) */
    int    student_number     = 24;       /* whole number                */
    double gpa                = 3.85;    /* decimal number (use double)  */
    int    is_enrolled        = 1;        /* 1 = true, 0 = false in C    */

    printf("\nStudent Profile:\n");
    printf("  Name    : %s\n",  student_name);
    printf("  Number  : %d\n",  student_number);
    printf("  GPA     : %.2f\n", gpa);         /* .2f means 2 decimal places */
    printf("  Enrolled: %s\n",  is_enrolled ? "Yes (true)" : "No (false)");
    /* The ? : above is a shortcut: if is_enrolled is 1 (true), print "Yes",
     * otherwise print "No". We will cover this fully in Layer 3.          */


    sub("EXAMPLE 1.3 — Variable Naming Rules");

    /* GOOD variable names — clear and readable */
    char   first_name[20]  = "Sarah"; /* use underscores to separate words */
    int    total_score      = 95;
    int    is_passing       = 1;      /* 1 = true */

    /* BAD variable names — confusing and unclear
     * char x[] = "Sarah";      what is x? nobody knows
     * int  ts  = 95;           what is ts?
     * int  ip  = 1;            what is ip?                              */

    /* RULE: Name your variables so someone else can READ your code
     *       like a sentence.                                             */

    printf("First Name : %s\n", first_name);
    printf("Total Score: %d\n", total_score);
    printf("Is Passing : %d (1=yes, 0=no)\n", is_passing);


    sub("EXAMPLE 1.4 — Swapping Variables");

    /* To swap two variables, you need a THIRD (temporary) variable
     * to hold one value while you do the swap. This is the same in
     * every language — C, Python, Java, all of them.                   */

    /* C does not have a built-in string swap shortcut like Python,
     * so we will use integers to clearly show the concept.             */
    int box_a = 100;
    int box_b = 200;

    printf("\nBefore swap:\n");
    printf("  box_a = %d\n", box_a);   /* 100 */
    printf("  box_b = %d\n", box_b);   /* 200 */

    /* Swap using a temporary variable */
    int temp = box_a;   /* Step 1: save box_a in temp              */
    box_a    = box_b;   /* Step 2: copy box_b's value into box_a   */
    box_b    = temp;    /* Step 3: copy temp's value into box_b    */

    printf("After swap:\n");
    printf("  box_a = %d\n", box_a);   /* 200 */
    printf("  box_b = %d\n", box_b);   /* 100 */

    /* For strings in C, use strcpy() from <string.h>
     * (We keep this separate to not confuse the concept)             */
    char drink_a[20] = "Water";
    char drink_b[20] = "Juice";
    char temp_str[20];

    printf("\nSwapping strings:\n");
    printf("  Before: drink_a=%s  drink_b=%s\n", drink_a, drink_b);

    strcpy(temp_str, drink_a);   /* save drink_a   */
    strcpy(drink_a,  drink_b);   /* a gets b       */
    strcpy(drink_b,  temp_str);  /* b gets saved a */

    printf("  After:  drink_a=%s  drink_b=%s\n", drink_a, drink_b);

} /* end of layer1_variables() */


/* ─────────────────────────────────────────────────────────────────────────────
 * CONCEPT: Data Types (in depth)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * C's core data types:
 *
 *   Type     | Size    | Range / Use
 *   ---------|---------|-----------------------------------------------
 *   char     | 1 byte  | Single character: 'A', 'z', '5'
 *   int      | 4 bytes | Whole numbers: -2 billion to +2 billion
 *   float    | 4 bytes | Decimal (6-7 significant digits precision)
 *   double   | 8 bytes | Decimal (15-16 significant digits — use this!)
 *
 * ⚠️  Prefer double over float for decimal numbers in most cases.
 *     float loses precision quickly.
 */

void layer1_datatypes() {

    section("LAYER 1 CONTINUED — DATA TYPES IN DEPTH");

    sub("EXAMPLE 1.5 — The Four Basic Data Types");

    int    my_integer = 42;
    double my_double  = 3.14159;
    char   my_char    = 'U';         /* single character — use SINGLE quotes */
    char   my_string[20] = "Hello, Uganda!"; /* string — use DOUBLE quotes   */
    int    my_bool    = 1;           /* 1 = true, 0 = false                  */

    /* In C, there is no type() function like Python.
     * You just know the type because YOU declared it.
     * Use the right format specifier in printf():
     *   %d for int, %f or %lf for double, %c for char, %s for string    */

    printf("  Value: %d    -> Type: int\n",    my_integer);
    printf("  Value: %.5f  -> Type: double\n", my_double);
    printf("  Value: %c    -> Type: char (single character)\n", my_char);
    printf("  Value: %s    -> Type: char[] (string)\n", my_string);
    printf("  Value: %d    -> Type: int used as bool (1=true, 0=false)\n", my_bool);


    sub("EXAMPLE 1.6 — Strings (Text) in Detail");

    /* In C, a string is an ARRAY of characters ending with '\0' (null terminator).
     * The null terminator '\0' is an invisible character that tells C:
     * "the string ends here."
     *
     *   char word[] = "Hi";
     *   Memory:  [ H ][ i ][ \0 ]
     *                          ↑ C adds this automatically
     */

    char greeting[20] = "Good morning";
    char person[10]   = "Mukasa";

    /* JOIN two strings: use strcat() — stands for "string concatenate"
     * ⚠️  The destination must be large enough to hold both strings!    */
    char full_greeting[50];
    strcpy(full_greeting, greeting);    /* copy "Good morning" into full_greeting */
    strcat(full_greeting, ", ");        /* add ", "                                */
    strcat(full_greeting, person);      /* add "Mukasa"                            */
    strcat(full_greeting, "!");         /* add "!"                                 */
    printf("  %s\n", full_greeting);    /* Good morning, Mukasa!                   */

    /* LENGTH of a string: use strlen() — stands for "string length"    */
    char word[20] = "University";
    int  length   = strlen(word);
    printf("  The word has %d letters\n", length);  /* 10 */

    /* ACCESS individual characters using their POSITION (index)
     * Positions start at 0, not 1 — same as Python!
     *
     *   U  n  i  v  e  r  s  i  t  y
     *   0  1  2  3  4  5  6  7  8  9
     */
    printf("  First letter: %c\n", word[0]);            /* U */
    printf("  Last letter : %c\n", word[length - 1]);   /* y */
    /* Note: C uses (length - 1) for last character; Python uses [-1] */

    /* REPEAT a character manually (C has no string * n shortcut) */
    printf("  ");
    for (int i = 0; i < 20; i++) printf("-");
    printf("\n");


    sub("EXAMPLE 1.7 — Integers vs Doubles (Numbers)");

    int    apples = 5;
    double price  = 1.50;

    double total = apples * price;

    printf("  Apples             : %d\n",     apples);
    printf("  Price per apple UGX: %.2f\n",   price);
    printf("  Total cost     UGX : %.2f\n",   total);

    /* Integer division in C: dividing two ints gives an int (no decimal) */
    int result_int = 7 / 2;
    printf("\n  7 / 2 (int division)    = %d\n", result_int);  /* 3, NOT 3.5! */

    /* ⚠️  This is a KEY difference from Python!
     *     Python: 7 / 2 → 3.5  (always float)
     *     C:      7 / 2 → 3    (int / int = int, decimal is DROPPED)
     *
     * To get the decimal result in C, make at least ONE number a double: */
    double result_double = 7.0 / 2;
    printf("  7.0 / 2 (double division) = %.1f\n", result_double);  /* 3.5 */

    /* Remainder (modulo) — same symbol % as Python */
    int remainder = 7 % 2;
    printf("  7 %% 2 (remainder)         = %d\n", remainder);  /* 1 */
    /* Note: in printf(), to print the % symbol itself, write %% */


    sub("EXAMPLE 1.8 — Type Casting (Changing a Type)");

    /* In C, you convert between types using a CAST: (type) value
     * This is different from Python's int(), float() functions.
     * Python: int(3.9)   → 3
     * C:      (int) 3.9  → 3                                            */

    double height = 5.9;
    int    height_as_int = (int) height;   /* cast: chop off decimal, NO rounding */

    printf("  Height as double : %.1f\n",  height);         /* 5.9 */
    printf("  Height as int    : %d\n",    height_as_int);  /* 5 (not 6!) */

    /* Force decimal division using a cast */
    int a = 7, b = 2;
    double precise = (double) a / b;   /* cast a to double BEFORE dividing */
    printf("  (double) 7 / 2   : %.1f\n", precise);         /* 3.5 */

    /* int to double — happens automatically (no data loss) */
    int    score   = 85;
    double dscore  = score;   /* C automatically widens int to double */
    printf("  Score as int     : %d\n",   score);
    printf("  Score as double  : %.1f\n", dscore);

    /* ⚠️  C does NOT have a simple way to convert a numeric string to int
     *     at this level. That concept is covered when we learn scanf().  */

} /* end of layer1_datatypes() */


/* ─────────────────────────────────────────────────────────────────────────────
 * CONCEPT: Constants
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * A constant is a value that NEVER changes during the program.
 * In C, we define constants with #define or the const keyword.
 *
 *   Method 1:  #define PI  3.14159       (preprocessor — no type, no semicolon)
 *   Method 2:  const double PI = 3.14159; (variable that is locked/read-only)
 *
 * Convention: Write constant names in ALL_CAPS so everyone knows they're fixed.
 *
 * ⚠️  #define lines go at the TOP of the file, before main().
 *     They are NOT inside a function.
 */

/* These are defined at the top of the file (file level, not inside main) */
#define PI              3.14159
#define MAX_STUDENTS    40
#define PASSING_GRADE   50

void layer1_constants() {

    section("LAYER 1 CONTINUED — CONSTANTS");

    sub("EXAMPLE 1.9 — Using Constants");

    /* Using #define constants */
    const char SCHOOL_NAME[] = "Uganda Christian University"; /* const string */

    int    radius       = 7;
    double area         = PI * radius * radius;

    printf("  School      : %s\n",     SCHOOL_NAME);
    printf("  Max class   : %d\n",     MAX_STUDENTS);
    printf("  Pass mark   : %d%%\n",   PASSING_GRADE);  /* %% prints a literal % */
    printf("  Circle area : %.5f\n",   area);

    /* If you try to change a const variable, the compiler will give an ERROR:
     *   PASSING_GRADE = 60;   <- this would cause a compile error
     * That is the whole point — constants protect important values.       */

} /* end of layer1_constants() */


/* ─────────────────────────────────────────────────────────────────────────────
 * CONCEPT: Operators
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * Operators are symbols that DO something to values.
 * C has the same 4 groups as Python:
 *
 *   1. Arithmetic  — do maths          (+, -, *, /, %, and no ** in C!)
 *   2. Assignment  — store values      (=, +=, -=, *=, /=)
 *   3. Comparison  — compare values    (==, !=, >, <, >=, <=)
 *   4. Logical     — combine true/false (&&, ||, !)
 *
 * KEY DIFFERENCE FROM PYTHON:
 *   Python uses:   and    or    not
 *   C uses:        &&     ||    !
 *
 *   Python: x > 0 and x < 10
 *   C:      x > 0 && x < 10
 *
 *   Python: not is_valid
 *   C:      !is_valid
 */

void layer1_operators() {

    section("LAYER 1 CONTINUED — OPERATORS");

    sub("EXAMPLE 1.10 — Arithmetic Operators");

    int a = 10;
    int b = 3;

    printf("  a = %d   b = %d\n\n", a, b);
    printf("  a + b  = %d\n",  a + b);   /* Addition       → 13   */
    printf("  a - b  = %d\n",  a - b);   /* Subtraction    → 7    */
    printf("  a * b  = %d\n",  a * b);   /* Multiplication → 30   */
    printf("  a / b  = %d\n",  a / b);   /* Integer div    → 3    */
    printf("  a %% b  = %d\n", a % b);   /* Modulo (remain)→ 1    */

    /* ⚠️  C does NOT have the ** operator for powers (Python does).
     *     In C, you must use the pow() function from <math.h>
     *     Example: pow(10, 3) → 1000  (10 to the power of 3)
     *     We show it here manually for clarity:                          */
    int power = 1;
    for (int i = 0; i < b; i++) power *= a;   /* 10 * 10 * 10 = 1000 */
    printf("  a ^ b  = %d  (10 to power 3, done with a loop)\n", power);


    sub("EXAMPLE 1.11 — Assignment Operators (Shorthand Updating)");

    int score = 100;
    printf("  Starting score: %d\n", score);

    score += 10;   /* same as: score = score + 10 */
    printf("  After bonus  (+10): %d\n", score);

    score -= 5;    /* same as: score = score - 5  */
    printf("  After penalty(-5) : %d\n", score);

    score *= 2;    /* same as: score = score * 2  */
    printf("  After doubling(*2): %d\n", score);

    score /= 3;    /* same as: score = score / 3  */
    printf("  After dividing (/3): %d\n", score);

    /* C also has ++ (add 1) and -- (subtract 1) shortcuts */
    int counter = 5;
    counter++;    /* same as counter = counter + 1 */
    printf("  Counter after ++  : %d\n", counter);   /* 6 */
    counter--;    /* same as counter = counter - 1 */
    printf("  Counter after --  : %d\n", counter);   /* 5 */


    sub("EXAMPLE 1.12 — Comparison Operators (Always Return 1 or 0)");

    /* ⚠️  C KEY POINT: Comparisons return 1 (true) or 0 (false).
     *     Python returns True or False (with capital letters).
     *     C uses plain integers: 1 means true, 0 means false.           */

    int x = 10;
    int y = 20;

    printf("  x = %d   y = %d\n\n", x, y);
    printf("  x == y  (x equals y?)       = %d\n", x == y);   /* 0 (false) */
    printf("  x != y  (x not equal to y?) = %d\n", x != y);   /* 1 (true)  */
    printf("  x > y   (x greater than y?) = %d\n", x > y);    /* 0 (false) */
    printf("  x < y   (x less than y?)    = %d\n", x < y);    /* 1 (true)  */
    printf("  x >= 10 (x at least 10?)    = %d\n", x >= 10);  /* 1 (true)  */
    printf("  x <= 9  (x at most 9?)      = %d\n", x <= 9);   /* 0 (false) */

    /* ⚠️  SAME COMMON MISTAKE AS PYTHON:
     *     =  is for ASSIGNING  (putting a value in a box)
     *     == is for COMPARING  (asking "are these the same?")
     *     They are NOT the same thing!                                   */


    sub("EXAMPLE 1.13 — Logical Operators (Combining True/False)");

    /* Python → C:
     *   and  →  &&   (both sides must be true)
     *   or   →  ||   (at least one side must be true)
     *   not  →  !    (flips true to false, false to true)               */

    int is_student   = 1;   /* 1 = true  */
    int has_id_card  = 0;   /* 0 = false */

    printf("  is_student  : %d\n", is_student);
    printf("  has_id_card : %d\n", has_id_card);
    printf("\n");

    int can_enter    = is_student && has_id_card;  /* both must be true */
    int can_discount = is_student || has_id_card;  /* at least one true */
    int not_student  = !is_student;                /* flip it           */

    printf("  Can enter library? (student AND has ID): %d\n", can_enter);    /* 0 */
    printf("  Can get discount?  (student OR  has ID): %d\n", can_discount); /* 1 */
    printf("  Is NOT a student:                        %d\n", not_student);  /* 0 */

    /* Real-world example: access to exam hall */
    int has_paid_fees   = 1;   /* true  */
    int registered      = 1;   /* true  */
    int has_been_barred = 0;   /* false */

    int can_sit_exam = has_paid_fees && registered && !has_been_barred;
    printf("\n  Can sit exam? %d  (1=yes, 0=no)\n", can_sit_exam);  /* 1 */

} /* end of layer1_operators() */


/* =============================================================================
 *
 *   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██████╗
 *   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ╚════██╗
 *   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝      ███╔╝
 *   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ██╔══╝
 *   ███████╗██║  ██║   ██║   ███████╗██║  ██║    ███████╗
 *   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚══════╝
 *
 *   INPUT & OUTPUT
 *
 * =============================================================================
 */

void layer2_io() {

    section("LAYER 2 — INPUT & OUTPUT");

    /* ─────────────────────────────────────────────────────────────────────────
     * CONCEPT: Output with printf()
     * ─────────────────────────────────────────────────────────────────────────
     *
     * printf() is C's way of printing to the screen.
     * It stands for "print formatted".
     *
     * FORMAT SPECIFIERS — these are placeholders for variables:
     *   %d   → integer
     *   %f   → float
     *   %lf  → double (use this for scanf when reading doubles)
     *   %c   → single character
     *   %s   → string (char array)
     *   %%   → literal percent sign
     *
     * ESCAPE SEQUENCES — special characters:
     *   \n  → newline (go to next line)
     *   \t  → tab (indent)
     *   \\  → literal backslash
     *   \"  → literal double quote inside a string
     */

    sub("EXAMPLE 2.1 — Different Ways to Use printf()");

    /* Basic printing */
    printf("  Hello, World!\n");

    /* Printing multiple values */
    printf("  Name: Grace   Age: %d\n", 20);

    /* Printing with tabs for alignment */
    printf("  Uganda\t|\tKenya\t|\tTanzania\n");

    /* Printing without moving to a new line (no \n at the end) */
    printf("  Loading");
    printf(" .");
    printf(" .");
    printf(" . Done!\n");

    /* Printing a blank line */
    printf("\n");


    sub("EXAMPLE 2.2 — Formatting Numbers in printf()");

    /* Python has f-strings. C uses format specifiers with width/precision.
     *   %10d   → integer, right-aligned in 10 characters of space
     *   %-10d  → integer, LEFT-aligned in 10 characters of space
     *   %.2f   → float/double, show exactly 2 decimal places
     *   %8.2f  → float, 8 chars wide, 2 decimal places                  */

    char  student_name[20] = "Tendo";
    int   score_val        = 78;
    char  grade_val[5]     = "B+";

    printf("  Student Name : %s\n",  student_name);
    printf("  Exam Score   : %d/100\n", score_val);
    printf("  Final Grade  : %s\n",  grade_val);

    /* Formatted number with thousands separator (manual in C) */
    int   items = 3;
    int   price = 2500;
    int   total = items * price;
    printf("  Total cost: UGX %d\n", total);   /* 7500 */

    /* Aligned table using width specifiers */
    printf("\n  %-15s %-10s %-10s\n", "Name", "Score", "Grade");
    printf("  -----------------------------------\n");
    printf("  %-15s %-10d %-10s\n", "Alice Namukasa", 92, "A");
    printf("  %-15s %-10d %-10s\n", "Bob Ssemwanga",  74, "B");
    printf("  %-15s %-10d %-10s\n", "Carol Tendo",    55, "C");
    printf("  %-15s %-10d %-10s\n", "David Mukisa",   40, "F");
    /* %-15s means: string, LEFT-align, take up 15 spaces               */


    sub("EXAMPLE 2.3 — Getting Input from the User with scanf()");

    /* scanf() is C's way of reading input from the user.
     * It is the equivalent of Python's input() function.
     *
     * SYNTAX:  scanf("%d", &variable_name);
     *                       ↑
     *                  The & symbol means "address of"
     *                  It tells scanf WHERE in memory to put the value.
     *                  You MUST include & for int, float, double, char.
     *                  You do NOT use & for strings (char arrays).
     *
     * Python:  name = input("Enter your name: ")     → always a string
     * C:       scanf("%s", name);                     → reads a string
     *          scanf("%d", &age);                     → reads an integer
     *
     * ⚠️  We are NOT calling scanf() here because this is a demo file
     *     that runs automatically. But here is EXACTLY how you write it:
     */

    printf("\n  [Simulated] Pretend the user typed: Gladys\n");
    printf("  [Simulated] Pretend the user typed age: 21\n");

    /* Simulating what scanf would have collected: */
    char  sim_name[20] = "Gladys";
    int   sim_age      = 21;

    printf("  [Simulated] Name read: %s\n", sim_name);
    printf("  [Simulated] Age  read: %d\n", sim_age);
    printf("  [Simulated] Age next year: %d\n", sim_age + 1);

    /* ── SCANF TEMPLATE (copy this into your own programs) ──────────────
     *
     *   int age;
     *   char name[50];
     *
     *   printf("Enter your name: ");
     *   scanf("%s", name);           // no & for strings
     *
     *   printf("Enter your age: ");
     *   scanf("%d", &age);           // & required for int
     *
     *   printf("Hello %s! You are %d years old.\n", name, age);
     *
     * ──────────────────────────────────────────────────────────────────*/


    sub("EXAMPLE 2.4 — Formatting Output Neatly (Aligned Columns)");

    /* Same table as Python version, using %-Ns for left-aligned columns */
    printf("\n  %-15s %-10s %-6s\n", "Name", "Score", "Grade");
    printf("  %.35s\n", "-----------------------------------");
    printf("  %-15s %-10d %-6s\n", "Alice Namukasa", 92, "A");
    printf("  %-15s %-10d %-6s\n", "Bob Ssemwanga",  74, "B");
    printf("  %-15s %-10d %-6s\n", "Carol Tendo",    55, "C");
    printf("  %-15s %-10d %-6s\n", "David Mukisa",   40, "F");

} /* end of layer2_io() */


/* =============================================================================
 *
 *   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██████╗
 *   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ╚════██╗
 *   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝      ███╔╝
 *   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ██╔══╝
 *   ███████╗██║  ██║   ██║   ███████╗██║  ██║    ███████╗
 *   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚══════╝
 *
 *   CONTROL FLOW — DECISIONS (if / else if / else / switch)
 *
 * =============================================================================
 */

void layer3_decisions() {

    section("LAYER 3 — CONTROL FLOW: DECISIONS (if / else if / else)");

    /* ─────────────────────────────────────────────────────────────────────────
     * CONCEPT: What is an if-statement?
     * ─────────────────────────────────────────────────────────────────────────
     *
     * An if-statement lets your program MAKE DECISIONS.
     * It asks a question, and if true, runs a block of code.
     *
     * C STRUCTURE:
     *
     *   if (condition) {
     *       // do this if condition is true
     *   } else if (another condition) {
     *       // do this if second condition is true
     *   } else {
     *       // do this if nothing above was true
     *   }
     *
     * KEY DIFFERENCES FROM PYTHON:
     *   Python: condition goes with NO brackets, indentation defines blocks
     *   C:      condition goes in ( ) brackets, blocks use { } curly braces
     *
     *   Python:  elif
     *   C:       else if   (two separate words)
     *
     *   Python:  and, or, not
     *   C:       &&,  ||,  !
     */

    sub("EXAMPLE 3.1 — Basic if / else");

    int temperature = 35;   /* degrees Celsius */

    if (temperature > 30) {
        /* This block only runs if temperature is greater than 30 */
        printf("  It is HOT outside! Stay hydrated.\n");
    } else {
        /* This block only runs if temperature is NOT greater than 30 */
        printf("  The weather is pleasant today.\n");
    }

    /* Change temperature to 22 and recompile — you'll see the other message! */


    sub("EXAMPLE 3.2 — if / else if / else (Multiple Choices)");

    /* Grading system — same logic as Python, just different syntax */
    int exam_score = 72;
    char grade[5];
    char remark[50];

    if (exam_score >= 90) {
        /* strcpy() copies a string into a char array */
        strcpy(grade,  "A");
        strcpy(remark, "Distinction — Excellent work!");
    } else if (exam_score >= 80) {
        strcpy(grade,  "B+");
        strcpy(remark, "Credit — Very good!");
    } else if (exam_score >= 70) {
        strcpy(grade,  "B");
        strcpy(remark, "Credit — Good work");
    } else if (exam_score >= 60) {
        strcpy(grade,  "C");
        strcpy(remark, "Pass — Keep pushing");
    } else if (exam_score >= 50) {
        strcpy(grade,  "D");
        strcpy(remark, "Pass — You can do better");
    } else {
        strcpy(grade,  "F");
        strcpy(remark, "Fail — Please see your lecturer");
    }

    printf("  Score : %d/100\n", exam_score);
    printf("  Grade : %s\n",     grade);
    printf("  Remark: %s\n",     remark);


    sub("EXAMPLE 3.3 — Nested if-statements (if inside an if)");

    /* Same security checkpoint logic as Python */
    int age_check     = 20;
    int has_student_id = 1;   /* 1 = true */

    if (age_check >= 18) {
        printf("  Age check: PASSED\n");

        if (has_student_id) {        /* same as:  if (has_student_id == 1) */
            printf("  ID check: PASSED\n");
            printf("  You may enter the exam hall.\n");
        } else {
            printf("  ID check: FAILED\n");
            printf("  Please get your student ID before entering.\n");
        }

    } else {
        printf("  Age check: FAILED\n");
        printf("  You must be at least 18 to take this exam.\n");
    }

    /* Notice the curly brace levels:
     * Outer if block uses { } at one level.
     * Inner if block uses { } nested inside.                            */


    sub("EXAMPLE 3.4 — Combining Conditions with && and ||");

    /* Python: and → C: &&     Python: or → C: ||   */

    char username[20] = "admin";
    char password[30] = "ucuSecure2024";

    /* strcmp() compares two strings. Returns 0 if they are EQUAL.
     * So strcmp(a, b) == 0 means "a equals b"                          */
    if (strcmp(username, "admin") == 0 && strcmp(password, "ucuSecure2024") == 0) {
        printf("  Login successful! Welcome, Admin.\n");
    } else {
        printf("  Incorrect username or password.\n");
    }

    printf("\n");

    /* Checking if a number is in a valid range */
    int student_age = 22;
    if (student_age >= 16 && student_age <= 35) {
        printf("  Age %d is valid for student registration.\n", student_age);
    } else {
        printf("  Age %d is outside the allowed range.\n", student_age);
    }

    printf("\n");

    /* Checking if a day is a weekend */
    char day[15] = "Saturday";
    if (strcmp(day, "Saturday") == 0 || strcmp(day, "Sunday") == 0) {
        printf("  %s is a weekend — no lectures!\n", day);
    } else {
        printf("  %s is a weekday — attend your classes!\n", day);
    }


    sub("EXAMPLE 3.5 — The Ternary Operator (One-Line if/else)");

    /* C has a ternary operator — a one-line shortcut for if/else.
     *
     * SYNTAX:   condition ? value_if_true : value_if_false
     *
     * Python:   result = "PASS" if marks >= 50 else "FAIL"
     * C:        char *result = marks >= 50 ? "PASS" : "FAIL";
     *
     * char * means "a pointer to a string" — basically, a string variable.
     * Don't worry about pointers yet; just know that char * holds text here.
     */

    int   marks  = 55;
    char *result = marks >= 50 ? "PASS" : "FAIL";
    printf("  Marks: %d  ->  Result: %s\n", marks, result);

    int   number = -7;
    char *sign   = number > 0 ? "positive" : "negative or zero";
    printf("  %d is %s\n", number, sign);


    sub("EXAMPLE 3.6 — Real-World Example: Internet Billing");

    int data_used_gb = 45;
    char *plan;
    int   bill_ugx;

    if (data_used_gb <= 10) {
        plan     = "Basic";
        bill_ugx = 50000;
    } else if (data_used_gb <= 30) {
        plan     = "Standard";
        bill_ugx = 120000;
    } else if (data_used_gb <= 60) {
        plan     = "Premium";
        bill_ugx = 200000;
    } else {
        plan     = "Unlimited";
        bill_ugx = 350000;
    }

    printf("  Data used   : %d GB\n", data_used_gb);
    printf("  Plan        : %s\n",    plan);
    printf("  Monthly bill: UGX %d\n", bill_ugx);


    sub("EXAMPLE 3.7 (BONUS C FEATURE) — switch / case");

    /* C has a special decision tool called switch/case.
     * Python does NOT have switch (until Python 3.10's match/case).
     * switch works ONLY with integers or single characters.
     *
     * SYNTAX:
     *   switch (variable) {
     *       case value1:
     *           // do this if variable == value1
     *           break;   ← IMPORTANT: must have break or it "falls through"
     *       case value2:
     *           // do this if variable == value2
     *           break;
     *       default:
     *           // do this if no case matched (like else)
     *   }
     */

    int day_number = 3;   /* 1=Monday, 2=Tuesday, 3=Wednesday, etc. */
    char *day_name;

    switch (day_number) {
        case 1:  day_name = "Monday";    break;
        case 2:  day_name = "Tuesday";   break;
        case 3:  day_name = "Wednesday"; break;
        case 4:  day_name = "Thursday";  break;
        case 5:  day_name = "Friday";    break;
        case 6:  day_name = "Saturday";  break;
        case 7:  day_name = "Sunday";    break;
        default: day_name = "Unknown";   break;
    }

    printf("  Day %d is: %s\n", day_number, day_name);

    /* ⚠️  ALWAYS include break; after each case.
     *     Without it, C will "fall through" and run the NEXT case too!
     *     This is a very common beginner bug in C.                      */

} /* end of layer3_decisions() */


/* =============================================================================
 *
 *   ██╗      █████╗ ██╗   ██╗███████╗██████╗     ██╗  ██╗
 *   ██║     ██╔══██╗╚██╗ ██╔╝██╔════╝██╔══██╗    ██║  ██║
 *   ██║     ███████║ ╚████╔╝ █████╗  ██████╔╝    ███████║
 *   ██║     ██╔══██║  ╚██╔╝  ██╔══╝  ██╔══██╗    ╚════██║
 *   ███████╗██║  ██║   ██║   ███████╗██║  ██║         ██║
 *   ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝  ╚═╝         ╚═╝
 *
 *   CONTROL FLOW — REPETITION (while, for, do-while, break, continue)
 *
 * =============================================================================
 */

void layer4_loops() {

    section("LAYER 4 — CONTROL FLOW: LOOPS (Repetition)");

    /* ─────────────────────────────────────────────────────────────────────────
     * CONCEPT: What is a Loop?
     * ─────────────────────────────────────────────────────────────────────────
     *
     * A loop lets you run the SAME block of code MULTIPLE TIMES
     * without writing it over and over again.
     *
     * C has THREE types of loops (Python only has two):
     *   1. while loop    — repeat AS LONG AS a condition is true
     *   2. for loop      — repeat a fixed number of times
     *   3. do-while loop — same as while, but ALWAYS runs at least once
     *
     * The while and for loops work the same as Python in logic.
     * The syntax uses ( ) for the condition and { } for the body.
     */

    /* ─── WHILE LOOP ──────────────────────────────────────────────────────── */

    sub("EXAMPLE 4.1 — Basic while Loop (Counting Up)");

    int count = 1;

    while (count <= 5) {
        /* This block runs again and again as long as count <= 5 */
        printf("  Count is: %d\n", count);
        count++;   /* ← CRITICAL: without this, we'd loop forever! */
    }
    printf("  Loop finished!\n\n");


    sub("EXAMPLE 4.2 — while Loop (Countdown)");

    int rocket = 10;

    printf("  Rocket launch countdown:\n");
    while (rocket >= 1) {
        printf("  T-minus %d...\n", rocket);
        rocket--;   /* count down by 1 each time */
    }
    printf("  LIFT OFF!\n\n");


    sub("EXAMPLE 4.3 — while Loop: Simulated Guessing Game");

    /* In C, we simulate the guessing game with a fixed array of guesses
     * (since we cannot use input() in a demo file).                     */
    int secret_number     = 7;
    int guesses[]         = {3, 9, 1, 7};  /* simulated user guesses     */
    int num_guesses       = 4;
    int attempt           = 0;
    int found             = 0;             /* 0 = false, 1 = true        */

    printf("  [Game] Guess the secret number between 1 and 10!\n");

    while (attempt < num_guesses) {
        int guess = guesses[attempt];
        attempt++;
        printf("  Guess #%d: %d  ->  ", attempt, guess);

        if (guess == secret_number) {
            printf("Correct! You got it in %d tries!\n", attempt);
            found = 1;
            break;
        } else if (guess < secret_number) {
            printf("Too low! Try higher.\n");
        } else {
            printf("Too high! Try lower.\n");
        }
    }

    if (!found) {
        printf("  Out of guesses. The number was %d.\n", secret_number);
    }


    sub("EXAMPLE 4.4 — while Loop: Summing Numbers 1 to 100");

    int total_sum = 0;
    int current   = 1;

    while (current <= 100) {
        total_sum += current;   /* add current to running total */
        current++;              /* move to next number          */
    }
    printf("  Sum of 1 to 100 = %d\n", total_sum);   /* 5050 */


    /* ─── FOR LOOP ───────────────────────────────────────────────────────── */
    /*
     * C's for loop is more explicit than Python's.
     *
     * Python:  for i in range(5):
     * C:       for (int i = 0; i < 5; i++)
     *               ↑             ↑       ↑
     *           start           stop    step
     *
     * The three parts of a C for loop:
     *   int i = 0   → initialise: create a counter, start at 0
     *   i < 5       → condition:  keep going while i is less than 5
     *   i++         → update:     add 1 to i after each iteration
     *
     * All three are separated by semicolons inside the ( ).
     */

    sub("EXAMPLE 4.5 — Basic for Loop");

    printf("  Counting from 0 to 4:\n");
    for (int i = 0; i < 5; i++) {
        printf("    i = %d\n", i);
    }

    printf("\n  Counting from 1 to 5:\n");
    for (int i = 1; i <= 5; i++) {    /* start at 1, go up to AND including 5 */
        printf("    i = %d\n", i);
    }


    sub("EXAMPLE 4.6 — for Loop with Different Step Sizes");

    printf("  Even numbers from 0 to 20:\n    ");
    for (int n = 0; n <= 20; n += 2) {   /* step by 2 */
        printf("%d ", n);
    }
    printf("\n");

    printf("  Odd numbers from 1 to 19:\n    ");
    for (int n = 1; n <= 19; n += 2) {   /* start at 1, step by 2 */
        printf("%d ", n);
    }
    printf("\n");

    printf("  Countdown from 10 to 1:\n    ");
    for (int n = 10; n >= 1; n--) {       /* start at 10, step by -1 */
        printf("%d ", n);
    }
    printf("\n");


    sub("EXAMPLE 4.7 — for Loop Over an Array of Items");

    /* C does not have Python's for-each loop over a list directly.
     * Instead, we loop over an ARRAY using an index variable.
     *
     * Python:
     *   fruits = ["mango", "jackfruit", "avocado"]
     *   for fruit in fruits: print(fruit)
     *
     * C:
     *   char fruits[][20] = {"mango", "jackfruit", "avocado"};
     *   for (int i = 0; i < 3; i++) printf("%s\n", fruits[i]);
     */

    char fruits[][20] = {"mango", "jackfruit", "avocado", "passion fruit", "banana"};
    int  num_fruits   = 5;

    printf("  My favourite Ugandan fruits:\n");
    for (int i = 0; i < num_fruits; i++) {
        printf("    - %s\n", fruits[i]);
    }

    /* Loop over each character in a string */
    char word_c[] = "CLANG";    /* renamed to avoid conflict */
    int  wlen     = strlen(word_c);
    printf("\n  Letters in the word %s:\n    ", word_c);
    for (int i = 0; i < wlen; i++) {
        printf("[%c] ", word_c[i]);   /* %c prints one character */
    }
    printf("\n");


    sub("EXAMPLE 4.8 — Nested Loops (A Loop Inside a Loop)");

    /* Same multiplication table and star pattern as Python */

    printf("  Multiplication table (3x3):\n\n");
    printf("     ");
    for (int col = 1; col <= 3; col++) printf("  x %d", col);
    printf("\n  --------------------\n");

    for (int row = 1; row <= 3; row++) {
        printf("  %d |", row);
        for (int col = 1; col <= 3; col++) {
            printf("  %3d", row * col);   /* %3d: right-align in 3 spaces */
        }
        printf("\n");
    }

    printf("\n  Star pattern using nested loops:\n");
    for (int row = 1; row <= 5; row++) {
        for (int col = 0; col < row; col++) {
            printf("* ");
        }
        printf("\n");
    }


    /* ─── DO-WHILE LOOP (C EXCLUSIVE!) ──────────────────────────────────── */
    /*
     * C has a third loop that Python does NOT have: do-while.
     *
     * DIFFERENCE:
     *   while   → checks condition BEFORE running the body
     *             (if condition is false from the start, body NEVER runs)
     *
     *   do-while → runs the body FIRST, THEN checks the condition
     *              (body ALWAYS runs at least once)
     *
     * SYNTAX:
     *   do {
     *       // code that runs at least once
     *   } while (condition);
     *            ← notice the semicolon at the end!
     *
     * Real-world use: input validation — keep asking until valid input given.
     */

    sub("EXAMPLE 4.9 (BONUS C FEATURE) — do-while Loop");

    /* Simulating a PIN entry that always shows the prompt at least once */
    int correct_pin      = 1234;
    int pins_to_try[]    = {9999, 1111, 1234};  /* simulated attempts */
    int pin_attempt      = 0;
    int entered_pin;

    printf("  [ATM PIN Simulation]\n");
    do {
        entered_pin = pins_to_try[pin_attempt];
        pin_attempt++;
        printf("  Entered PIN: %d  ->  ", entered_pin);

        if (entered_pin == correct_pin) {
            printf("Access Granted!\n");
        } else {
            printf("Wrong PIN. Try again.\n");
        }
    } while (entered_pin != correct_pin && pin_attempt < 3);

    /* The do block ALWAYS runs at least once, even if the first PIN was right */


    /* ─── BREAK AND CONTINUE ─────────────────────────────────────────────── */

    sub("EXAMPLE 4.10 — break: Stopping a Loop Early");

    /* break works EXACTLY the same in C as in Python */
    printf("  Searching for first even number divisible by 3:\n");
    for (int n = 1; n < 50; n++) {
        if (n % 2 == 0 && n % 3 == 0) {
            printf("  Found it: %d\n", n);
            break;   /* stop immediately — we found what we needed */
        }
        printf("  Checked %d — not it\n", n);
    }

    printf("\n  Security gate — stop after 3 failed attempts:\n");

    char *passwords[] = {"wrong1", "wrong2", "wrongAgain", "correct123"};
    int   pw_attempts  = 0;
    int   pw_count     = 4;

    for (int i = 0; i < pw_count; i++) {
        if (pw_attempts >= 3) {
            printf("  Too many failed attempts. System locked.\n");
            break;
        }
        if (strcmp(passwords[i], "correct123") == 0) {
            printf("  Access granted with password: %s\n", passwords[i]);
            break;
        } else {
            pw_attempts++;
            printf("  Wrong password: %s (attempt %d)\n", passwords[i], pw_attempts);
        }
    }


    sub("EXAMPLE 4.11 — continue: Skipping One Iteration");

    /* continue works EXACTLY the same in C as in Python */

    printf("  Printing only ODD numbers (skip even ones):\n  ");
    for (int n = 1; n <= 10; n++) {
        if (n % 2 == 0) {
            continue;   /* skip even numbers */
        }
        printf("%d ", n);
    }
    printf("\n\n");

    /* Attendance — skip absent students */
    char *names[]   = {"Alice", "Bob",    "Carol",   "David",  "Eve"};
    int   present[] = {1,        0,        1,          0,        1  };  /* 1=present, 0=absent */
    int   num_class = 5;

    printf("  Marking attendance:\n");
    for (int i = 0; i < num_class; i++) {
        if (!present[i]) {
            printf("  [ABSENT] %s is absent — skipping\n", names[i]);
            continue;
        }
        printf("  [PRESENT] %s — marked present\n", names[i]);
    }


    sub("EXAMPLE 4.12 — Real-World Loop: Processing a List of Scores");

    int scores[]  = {88, 45, 72, 91, 38, 67, 55, 80, 29, 77};
    int num_scores = 10;

    int total_sc  = 0;
    int passed    = 0;
    int failed    = 0;
    int highest   = scores[0];
    int lowest    = scores[0];

    printf("  Processing exam scores...\n\n");

    for (int i = 0; i < num_scores; i++) {
        int score = scores[i];
        total_sc += score;

        char *status;
        if (score >= 50) {
            passed++;
            status = "PASS";
        } else {
            failed++;
            status = "FAIL";
        }

        if (score > highest) highest = score;
        if (score < lowest)  lowest  = score;

        printf("  Score: %3d  ->  %s\n", score, status);
    }

    double average = (double) total_sc / num_scores;

    printf("\n  --- Summary -------------------\n");
    printf("  Total students : %d\n",   num_scores);
    printf("  Passed         : %d\n",   passed);
    printf("  Failed         : %d\n",   failed);
    printf("  Highest score  : %d\n",   highest);
    printf("  Lowest score   : %d\n",   lowest);
    printf("  Average score  : %.1f\n", average);


    sub("EXAMPLE 4.13 — FizzBuzz (Classic Programming Exercise)");

    /* Same rules as Python:
     * Divisible by 3 → Fizz
     * Divisible by 5 → Buzz
     * Divisible by both → FizzBuzz
     * Otherwise → print the number
     * Check BOTH first (FizzBuzz), then each alone.                     */

    printf("  FizzBuzz from 1 to 30:\n\n");

    for (int n = 1; n <= 30; n++) {
        if      (n % 3 == 0 && n % 5 == 0) printf("  %2d -> FizzBuzz\n", n);
        else if (n % 3 == 0)                printf("  %2d -> Fizz\n",     n);
        else if (n % 5 == 0)                printf("  %2d -> Buzz\n",     n);
        else                                printf("  %2d -> %d\n",       n, n);
    }

} /* end of layer4_loops() */


/* =============================================================================
 *
 *   ███╗   ███╗ █████╗ ██╗███╗   ██╗
 *   ████╗ ████║██╔══██╗██║████╗  ██║
 *   ██╔████╔██║███████║██║██╔██╗ ██║
 *   ██║╚██╔╝██║██╔══██║██║██║╚██╗██║
 *   ██║ ╚═╝ ██║██║  ██║██║██║ ╚████║
 *   ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝
 *
 *   main() — WHERE EVERY C PROGRAM STARTS
 *
 * =============================================================================
 *
 * In C, execution ALWAYS begins at main().
 * This is different from Python where code runs top-to-bottom automatically.
 * In C, you write your logic in functions, then CALL them from main().
 *
 * int main() means: "this function returns an integer to the operating system"
 * return 0; at the end means: "everything finished successfully" (0 = OK)
 */

int main() {

    /* Call each layer's function in order */
    layer1_variables();
    layer1_datatypes();
    layer1_constants();
    layer1_operators();
    layer2_io();
    layer3_decisions();
    layer4_loops();

    /* ── SUMMARY ─────────────────────────────────────────────────────────── */

    section("SUMMARY — WHAT YOU HAVE LEARNED");

    printf("\n");
    printf("  LAYER 1 — DATA\n");
    printf("  |-- Variables   : Declared with a type — int age = 17;\n");
    printf("  |-- Data Types  : int, double, char, char[] (string)\n");
    printf("  |-- Constants   : #define PI 3.14159  or  const int X = 5;\n");
    printf("  +-- Operators   : +,-,*,/,%%  |  +=,-=  |  ==,!=,<,>  |  &&,||,!\n");
    printf("\n");
    printf("  LAYER 2 — INPUT & OUTPUT\n");
    printf("  |-- printf()    : Print to screen using format specifiers\n");
    printf("  |-- scanf()     : Read from user (use & for non-strings!)\n");
    printf("  |-- Format spec : %%d=int  %%f=float  %%lf=double  %%s=string  %%c=char\n");
    printf("  +-- Formatting  : %%-15s for left-aligned columns, %%.2f for 2 decimals\n");
    printf("\n");
    printf("  LAYER 3 — DECISIONS\n");
    printf("  |-- if/else if  : Condition in () brackets, block in {} braces\n");
    printf("  |-- else if     : Two words in C (Python uses 'elif')\n");
    printf("  |-- &&  ||  !   : C's and/or/not (Python uses words)\n");
    printf("  |-- Ternary     : cond ? true_val : false_val\n");
    printf("  +-- switch/case : C's special multi-branch decision tool\n");
    printf("\n");
    printf("  LAYER 4 — LOOPS\n");
    printf("  |-- while       : while (condition) { ... }\n");
    printf("  |-- for         : for (init; condition; update) { ... }\n");
    printf("  |-- do-while    : Runs body first, checks condition after (C only!)\n");
    printf("  |-- break       : Exit the loop immediately\n");
    printf("  +-- continue    : Skip this iteration, go to next\n");
    printf("\n");
    printf("  KEY C vs PYTHON DIFFERENCES TO REMEMBER:\n");
    printf("  |-- C needs type declarations:  int age = 17;  (Python: age = 17)\n");
    printf("  |-- C uses ; at end of every statement\n");
    printf("  |-- C uses {} for blocks  (Python uses indentation)\n");
    printf("  |-- C uses &&, ||, !  (Python uses and, or, not)\n");
    printf("  |-- C int/int division drops decimal  (Python / always gives float)\n");
    printf("  |-- C strings need strcpy/strcat/strcmp  (Python: +, len, ==)\n");
    printf("  +-- C has do-while and switch/case  (Python does not)\n");
    printf("\n");
    printf("  ---------------------------------------------------------\n");
    printf("  NEXT UP: Layer 5 -> Functions (the most important layer!)\n");
    printf("  ---------------------------------------------------------\n");
    printf("\n");
    printf("  Remember: Programming is not about memorising syntax.\n");
    printf("  It is about learning to THINK in steps.\n");
    printf("  Read every example. Change the values. Break things.\n");
    printf("  That is how you truly learn.\n");
    printf("\n");
    printf("  -- Paul Ifemene, Code Buddy Mentor, UCU 2026\n");
    printf("\n");

    return 0;   /* 0 = success. The OS receives this when the program ends. */

} /* end of main() */

/* =============================================================================
 *   END OF FILE
 *
 *   HOW TO COMPILE AND RUN (reminder):
 *   ------------------------------------
 *   gcc structured_programming_guide.c -o guide
 *   ./guide
 * =============================================================================
 */
